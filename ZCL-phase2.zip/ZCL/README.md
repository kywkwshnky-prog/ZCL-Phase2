# ZAMHREER CYBER LAB — Phase 2
Kotlin + Jetpack Compose, Arabic RTL, minSdk 26.

## Ready (real implementations)
- Z-Hash: SHA-256/512, streaming, cancel, compare with reference.
- Z-Encrypt: AES-256-GCM streaming (Google Tink), PBKDF2-HMAC-SHA256 600k iters, header authenticated, output written only after full verification, original never overwritten.
- Z-KeySafe: random 256-bit keys wrapped by non-exportable Android Keystore key; password-encrypted export.
- Z-Pass Audit: local strength check + secure generator.
- Local log counters, About (Telegram button), Settings (clear log).

## Not implemented yet (shown as "قيد التطوير")
Z-Scan, Z-Link Shield, Z-Net, Z-Code Shield, Z-File Guard, Z-Privacy, Z-Intel, Z-Incident, Z-Report, Z-Academy, Vault, Update center.
Argon2id is not included (PBKDF2 is the documented fallback).

## Build (nothing here has been compiled or tested yet)
- Cloud: push to a GitHub repo -> Actions -> "Build APK" runs `gradle test assembleDebug` and uploads the APK artifact.
- Local: Android Studio, or `gradle wrapper --gradle-version 8.7` then `./gradlew test assembleDebug`.
Debug APK is signed with the debug key; a release build needs your own keystore (never upload it to untrusted services).
