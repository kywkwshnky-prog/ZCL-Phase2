package com.zamhreer.zcl

import com.zamhreer.zcl.analysis.*
import org.junit.Assert.*
import org.junit.Test
import java.net.InetAddress

class NetTest {
    @Test fun blocksPrivate() {
        listOf("127.0.0.1", "10.0.0.5", "192.168.1.1", "172.16.5.5", "169.254.169.254", "100.64.0.1", "0.0.0.0", "::1", "fd00::1")
            .forEach { assertTrue(it, NetGuard.isBlocked(InetAddress.getByName(it))) }
    }
    @Test fun allowsPublic() { assertFalse(NetGuard.isBlocked(InetAddress.getByName("8.8.8.8"))) }
    @Test fun hostBlocked() {
        listOf("localhost", "intranet", "foo.local", "127.0.0.1", "2130706433", "[::1]", "192.168.0.1").forEach { assertTrue(it, NetGuard.hostBlocked(it)) }
        assertFalse(NetGuard.hostBlocked("example.com"))
    }
    @Test fun lanTarget() {
        assertEquals(254, NetGuard.parseLanTarget("192.168.1.0/24").first!!.size)
        assertEquals(listOf("10.0.0.7"), NetGuard.parseLanTarget("10.0.0.7").first)
        assertNull(NetGuard.parseLanTarget("8.8.8.8").first)
        assertNull(NetGuard.parseLanTarget("192.168.0.0/16").first)
    }
    @Test fun portParsing() {
        assertEquals(listOf(22, 80), LanScan.parsePorts("22, 80").first)
        assertNull(LanScan.parsePorts("0").first)
        assertNull(LanScan.parsePorts("1,2,3,4,5,6,7,8,9,10,11").first)
    }
    @Test fun headersMissing() {
        val ids = ZScan.evaluateHeaders(emptyMap(), emptyList(), true).map { it.id }
        assertTrue(ids.containsAll(listOf("WEB-CSP", "WEB-HSTS", "WEB-XCTO", "WEB-FRAME")))
    }
    @Test fun headersGood() {
        val h = mapOf("content-security-policy" to "default-src 'self'; frame-ancestors 'self'", "strict-transport-security" to "max-age=31536000",
            "x-content-type-options" to "nosniff", "referrer-policy" to "no-referrer", "permissions-policy" to "camera=()")
        assertTrue(ZScan.evaluateHeaders(h, emptyList(), true).isEmpty())
    }
    @Test fun cookieFlags() {
        val ids = ZScan.evaluateHeaders(emptyMap(), listOf("sid=abc123; Path=/"), true).map { it.id }
        assertTrue(ids.containsAll(listOf("WEB-COOKIE-SECURE", "WEB-COOKIE-HTTPONLY")))
    }
}
