package com.zamhreer.zcl

import com.zamhreer.zcl.crypto.*
import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.SecureRandom

class ZclCryptoTest {
    private val key = ZclCrypto.randomKey()
    private fun enc(data: ByteArray, s: Secret) = ZclCrypto.encryptBytes(data, s)
    private fun dec(data: ByteArray, s: Secret): ByteArray {
        val o = ByteArrayOutputStream(); ZclCrypto.decrypt(ByteArrayInputStream(data), o, s); return o.toByteArray()
    }
    private fun rnd(n: Int) = ByteArray(n).also { SecureRandom().nextBytes(it) }

    @Test fun roundTripKey() { val d = rnd(100_000); assertArrayEquals(d, dec(enc(d, Secret.Key(key)), Secret.Key(key))) }
    @Test fun emptyFile() { assertArrayEquals(ByteArray(0), dec(enc(ByteArray(0), Secret.Key(key)), Secret.Key(key))) }
    @Test fun roundTripPassword() {
        val d = rnd(10_000)
        val c = enc(d, Secret.Password("correct horse".toCharArray()))
        assertArrayEquals(d, dec(c, Secret.Password("correct horse".toCharArray())))
    }
    @Test(expected = ZclCryptoException::class) fun wrongPassword() {
        val c = enc(rnd(1000), Secret.Password("correct horse".toCharArray()))
        dec(c, Secret.Password("wrong".toCharArray()))
    }
    @Test(expected = ZclCryptoException::class) fun tampered() {
        val c = enc(rnd(50_000), Secret.Key(key)); c[c.size / 2] = (c[c.size / 2].toInt() xor 1).toByte()
        dec(c, Secret.Key(key))
    }
    @Test(expected = ZclCryptoException::class) fun truncated() {
        val c = enc(rnd(50_000), Secret.Key(key)); dec(c.copyOf(c.size - 10), Secret.Key(key))
    }
    @Test(expected = ZclCryptoException::class) fun corruptedHeader() {
        val c = enc(rnd(1000), Secret.Key(key)); c[0] = 0; dec(c, Secret.Key(key))
    }
    @Test fun hashKnownVector() {
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
            ZclHash.compute(ByteArrayInputStream("abc".toByteArray()), "SHA-256"))
    }
}
