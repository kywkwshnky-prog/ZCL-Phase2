package com.zamhreer.zcl

import com.zamhreer.zcl.analysis.*
import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream

class AnalysisTest {
    @Test fun phishingLinkFlagged() {
        val r = LinkAnalyzer.analyze("http://paypal.com.secure-login.xyz/verify/account")
        assertTrue(r.verdict == "خطر مرتفع" || r.verdict == "مشبوه")
        assertTrue(r.findings.any { it.id.startsWith("LNK-BRAND") })
    }
    @Test fun userInfoTrick() {
        assertTrue(LinkAnalyzer.analyze("https://google.com@evil.example/login").findings.any { it.id == "LNK-USERINFO" })
    }
    @Test fun cleanLink() { assertEquals("لم تُكتشف مؤشرات واضحة", LinkAnalyzer.analyze("https://www.wikipedia.org/").verdict) }
    @Test fun shortLink() { assertTrue(LinkAnalyzer.analyze("https://bit.ly/abc").findings.any { it.id == "LNK-SHORT" }) }
    @Test fun phpSqlLineNumber() {
        val r = CodeShield.analyze("a.php", "<?php\n\$q = \"SELECT * FROM t WHERE id=\" . \$_GET['id'];\n")
        assertTrue(r.findings.any { it.id == "PHP001" && it.line == 2 })
    }
    @Test fun secretMasked() {
        val r = CodeShield.analyze("c.py", "password = \"SuperSecret123\"\n")
        val f = r.findings.first { it.id == "SEC001" }
        assertFalse(f.evidence.contains("SuperSecret123"))
    }
    @Test fun pyEval() { assertTrue(CodeShield.analyze("x.py", "eval(input())").findings.any { it.id == "PY001" }) }
    @Test fun safeCode() { assertTrue(CodeShield.analyze("x.py", "print('hi')\n").findings.isEmpty()) }
    @Test fun fileMismatchExec() {
        val mz = byteArrayOf(0x4D, 0x5A, 0, 0, 0, 0, 0, 0)
        val r = FileGuard.analyze("photo.jpg", { ByteArrayInputStream(mz) })
        assertTrue(r.findings.any { it.id == "FG-EXEC-MISMATCH" })
    }
    @Test fun emptyFile() { assertTrue(FileGuard.analyze("a.txt", { ByteArrayInputStream(ByteArray(0)) }).findings.any { it.id == "FG-EMPTY" }) }
}
