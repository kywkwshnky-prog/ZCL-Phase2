package com.zamhreer.zcl.analysis

import java.net.URI

/** Local-only URL analysis. It never connects to the link and never opens it. */
object LinkAnalyzer {
    const val RULES_VERSION = "ZCL-LINK-1.0.0"
    val LIMITS = listOf(
        "تحليل محلي لبنية الرابط فقط؛ لا يتصل بالرابط ولا يفحص محتوى الصفحة.",
        "لم يُستخدم فحص سمعة خارجي.",
        "استخراج النطاق الأساسي تقريبي (آخر مقطعين) وقد لا يناسب نطاقات مثل co.uk.",
        "أي مؤشر منفرد ليس دليلاً قاطعاً على الاحتيال."
    )

    data class Result(val url: String, val verdict: String, val score: Int, val findings: List<Finding>)

    private val shorteners = setOf("bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "cutt.ly", "rb.gy", "ow.ly",
        "shorturl.at", "tiny.cc", "t.ly", "rebrand.ly", "s.id", "bl.ink", "lnkd.in")
    private val brands = listOf("paypal", "google", "apple", "microsoft", "facebook", "instagram", "whatsapp",
        "telegram", "amazon", "netflix", "binance", "snapchat", "tiktok", "youtube", "zaincash", "asiacell", "korek", "zain")
    private val riskyTlds = setOf("zip", "mov", "xyz", "top", "tk", "ml", "ga", "cf", "gq", "click", "country", "work", "support", "rest")
    private val bait = listOf("login", "signin", "verify", "update", "secure", "account", "password", "wallet", "bank", "confirm", "gift", "prize", "free")
    private val ipv4 = Regex("""^\d{1,3}(\.\d{1,3}){3}$""")
    private val numericIp = Regex("""^(0x[0-9a-f]+|\d{8,10})$""", RegexOption.IGNORE_CASE)

    private fun f(id: String, t: String, s: Severity, c: String, ev: String, why: String, fix: String) =
        Finding(id, t, s, c, ev, why, fix)

    fun analyze(raw: String): Result {
        val input = raw.trim()
        val findings = mutableListOf<Finding>()
        if (input.isEmpty()) return Result(raw, "تعذر الفحص", 0, emptyList())
        val hasScheme = Regex("""^[A-Za-z][A-Za-z0-9+.-]*:""").containsMatchIn(input)
        val withScheme = if (input.contains("://") || (hasScheme && !Regex("""^[^/]+:\d+""").containsMatchIn(input))) input else "http://$input"
        val uri = try { URI(withScheme) } catch (e: Exception) {
            findings += f("LNK-PARSE", "رابط غير صالح الصيغة", Severity.MEDIUM, "متوسطة", input.take(120),
                "الرابط يحتوي أحرفاً أو بنية غير قياسية.", "لا تفتحه إلا إن عرفت مصدره.")
            return Result(input, "تعذر الفحص", Severity.MEDIUM.weight, findings)
        }
        val scheme = (uri.scheme ?: "").lowercase()
        val host = (uri.host ?: withScheme.substringAfter("://").substringBefore('/').substringAfter('@').substringBefore(':')).lowercase()
        if (!input.contains("://") && !hasScheme)
            findings += f("LNK-NOSCHEME", "الرابط بلا بروتوكول", Severity.INFO, "عالية", input.take(80), "افترض التحليل http.", "تحقق من البروتوكول قبل الفتح.")
        if (scheme != "http" && scheme != "https")
            findings += f("LNK-SCHEME", "بروتوكول غير ويب: $scheme", Severity.HIGH, "عالية", "$scheme:", "بروتوكولات مثل javascript وdata قد تنفذ محتوى.", "لا تفتح هذا الرابط.")
        if (scheme == "http")
            findings += f("LNK-HTTP", "بدون تشفير (HTTP)", Severity.LOW, "عالية", "http://", "البيانات المرسلة قد تُقرأ أو تُعدل في الطريق.", "لا تدخل بيانات حساسة.")
        if (uri.rawUserInfo != null)
            findings += f("LNK-USERINFO", "بيانات اعتماد/نص قبل @ داخل الرابط", Severity.HIGH, "عالية", "…@$host",
                "أسلوب شائع لإخفاء الوجهة الحقيقية خلف اسم مألوف.", "الوجهة الحقيقية هي ما بعد @ — تجنب الرابط.")
        if (host.isNotEmpty()) {
            if (ipv4.matches(host) || numericIp.matches(host) || host.startsWith("["))
                findings += f("LNK-IP", "عنوان IP بدل اسم نطاق", Severity.MEDIUM, "متوسطة", host, "المواقع الموثوقة نادراً تُعرض بعنوان IP مباشر.", "تحقق من مصدر الرابط.")
            if (host.split('.').any { it.startsWith("xn--") })
                findings += f("LNK-PUNY", "نطاق Punycode (xn--)", Severity.HIGH, "متوسطة", host, "قد يخفي أحرفاً مشابهة لحروف معروفة (انتحال بصري).", "اكتب عنوان الموقع بنفسك بدل الرابط.")
            if (host.any { it.code > 127 }) {
                val scripts = host.filter { it.isLetter() }.map { Character.UnicodeScript.of(it.code) }.toSet()
                val mixed = scripts.size > 1
                findings += f("LNK-UNICODE", "أحرف دولية في النطاق" + if (mixed) " (خلط أنظمة كتابة)" else "",
                    if (mixed) Severity.HIGH else Severity.MEDIUM, "متوسطة", host, "أحرف متشابهة بصرياً قد تنتحل نطاقاً معروفاً.", "تحقق من النطاق الحقيقي.")
            }
            if (host in shorteners)
                findings += f("LNK-SHORT", "رابط مختصر", Severity.MEDIUM, "عالية", host, "الوجهة النهائية مخفية.", "استخدم خدمة توسيع روابط موثوقة قبل الفتح.")
            val labels = host.split('.')
            if (labels.size >= 5)
                findings += f("LNK-SUBS", "نطاقات فرعية كثيرة", Severity.MEDIUM, "متوسطة", host, "تُستخدم لإظهار اسم مألوف في بداية الرابط.", "انظر إلى آخر مقطعين من النطاق.")
            val registrable = if (labels.size >= 2) labels.takeLast(2).joinToString(".") else host
            val normalized = host.replace('0', 'o').replace('1', 'l').replace('3', 'e').replace('5', 's')
            brands.forEach { b ->
                val official = registrable.startsWith("$b.")
                if (host.contains(b) && !official)
                    findings += f("LNK-BRAND-$b", "اسم \"$b\" داخل نطاق مختلف", Severity.HIGH, "متوسطة", host,
                        "النطاق الأساسي ($registrable) ليس نطاق $b المعروف.", "افتح الموقع الرسمي يدوياً.")
                else if (!host.contains(b) && normalized.contains(b) && !official)
                    findings += f("LNK-LEET-$b", "تمويه حروف يشبه \"$b\"", Severity.HIGH, "متوسطة", host, "استبدال حروف بأرقام لمحاكاة اسم معروف.", "تجنب الرابط.")
            }
            if (registrable.count { it == '-' } >= 3)
                findings += f("LNK-HYPH", "شرطات كثيرة في النطاق", Severity.LOW, "منخفضة", registrable, "نمط شائع في نطاقات التصيد.", "كن حذراً.")
            val tld = labels.last()
            if (tld in riskyTlds)
                findings += f("LNK-TLD", "امتداد نطاق كثير الإساءة (.$tld)", Severity.LOW, "منخفضة", host, "مؤشر ضعيف وحده.", "اجمعه مع باقي المؤشرات.")
        }
        val port = uri.port
        if (port != -1 && port != 80 && port != 443)
            findings += f("LNK-PORT", "منفذ غير معتاد: $port", Severity.LOW, "منخفضة", ":$port", "مواقع عامة قليلة تستخدمه.", "تحقق من المصدر.")
        val path = ((uri.rawPath ?: "") + "?" + (uri.rawQuery ?: "")).lowercase()
        val hits = bait.filter { path.contains(it) }
        if (hits.size >= 2)
            findings += f("LNK-BAIT", "كلمات استدراج في المسار", Severity.LOW, "منخفضة", hits.joinToString(), "تتكرر في صفحات التصيد.", "لا تدخل بيانات عبر رابط وصلك.")
        if (Regex("""(?i)[?&](url|redirect|redirect_uri|next|goto|return|continue)=https?""").containsMatchIn(input))
            findings += f("LNK-REDIR", "معامل إعادة توجيه لموقع آخر", Severity.MEDIUM, "متوسطة", "redirect=…", "قد يمرّرك إلى وجهة مختلفة.", "افحص الوجهة داخل المعامل.")
        if (Regex("""%[0-9a-fA-F]{2}""").findAll(input).count() >= 8)
            findings += f("LNK-ENC", "ترميز مفرط (%XX)", Severity.LOW, "منخفضة", "", "قد يُخفي محتوى الرابط.", "فك الترميز قبل الحكم.")
        if (input.length > 200)
            findings += f("LNK-LONG", "رابط طويل جداً (${input.length})", Severity.LOW, "منخفضة", "", "قد يحمل رموز تتبع أو يخفي الوجهة.", "تحقق من النطاق فقط.")

        val score = findings.sumOf { it.severity.weight }
        val verdict = when {
            score >= 60 -> "خطر مرتفع"
            score >= 25 -> "مشبوه"
            findings.none { it.severity != Severity.INFO } -> "لم تُكتشف مؤشرات واضحة"
            else -> "غير كافٍ للحكم"
        }
        return Result(input, verdict, score, findings.sortedByDescending { it.severity.weight })
    }
}
