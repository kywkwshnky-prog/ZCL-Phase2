package com.zamhreer.zcl.analysis

import java.net.InetAddress

/** Address safety checks used by every network-facing engine (SSRF protection). */
object NetGuard {
    fun isBlocked(a: InetAddress): Boolean {
        if (a.isAnyLocalAddress || a.isLoopbackAddress || a.isLinkLocalAddress || a.isSiteLocalAddress || a.isMulticastAddress) return true
        val b = a.address
        if (b.size == 4) {
            val o = b.map { it.toInt() and 0xFF }
            if (o[0] == 0) return true
            if (o[0] == 100 && o[1] in 64..127) return true
            if (o[0] == 192 && o[1] == 0 && o[2] == 0) return true
            if (o[0] == 198 && o[1] in 18..19) return true
            if (o[0] >= 240) return true
        } else if (b.size == 16) {
            if ((b[0].toInt() and 0xFE) == 0xFC) return true
            if (b[0].toInt() == 0x20 && b[1].toInt() == 0x01 && b[2].toInt() == 0x0D && b[3].toInt() == 0xB8) return true
        }
        return false
    }

    /** True when the host must not be contacted by the public-site scanner. */
    fun hostBlocked(rawHost: String): Boolean {
        val h = rawHost.trim().trim('[', ']').lowercase()
        if (h.isEmpty()) return true
        if (h == "localhost" || h.endsWith(".localhost") || h.endsWith(".local") || h.endsWith(".internal") || h.endsWith(".lan")) return true
        if (!h.contains('.') && !h.contains(':')) return true
        val v4 = Regex("""^[0-9.]+$""").matches(h)
        val v6 = h.contains(':') && Regex("""^[0-9a-f:.]+$""").matches(h)
        if (v4 || v6) {
            return try { isBlocked(InetAddress.getByName(h)) } catch (e: Exception) { true }
        }
        return false
    }

    private fun parseV4(s: String): IntArray? {
        val p = s.split('.')
        if (p.size != 4) return null
        val o = p.map { it.toIntOrNull() ?: return null }
        return if (o.all { it in 0..255 }) o.toIntArray() else null
    }

    private fun privateV4(o: IntArray) = o[0] == 10 || (o[0] == 172 && o[1] in 16..31) || (o[0] == 192 && o[1] == 168) || o[0] == 127

    /** Parses "192.168.1.5" or "192.168.1.0/24" (prefix 24..32, private ranges only). */
    fun parseLanTarget(text: String): Pair<List<String>?, String> {
        val t = text.trim()
        val ipPart = t.substringBefore('/')
        val o = parseV4(ipPart) ?: return null to "صيغة غير صحيحة. مثال: 192.168.1.0/24 أو 192.168.1.5"
        if (!privateV4(o)) return null to "مسموح فقط بالعناوين الخاصة (10.x / 172.16-31.x / 192.168.x)."
        val prefix = if (t.contains('/')) (t.substringAfter('/').toIntOrNull() ?: return null to "بادئة غير صحيحة") else 32
        if (prefix !in 24..32) return null to "الحد الأقصى للنطاق /24 (256 جهازاً)."
        val ip = (o[0] shl 24) or (o[1] shl 16) or (o[2] shl 8) or o[3]
        val mask = if (prefix == 0) 0 else (-1 shl (32 - prefix))
        val start = ip and mask
        val count = 1 shl (32 - prefix)
        val hosts = (0 until count).map { start + it }.filter { count <= 2 || (it != start && it != start + count - 1) }
            .map { "${(it ushr 24) and 255}.${(it ushr 16) and 255}.${(it ushr 8) and 255}.${it and 255}" }
        return hosts to ""
    }
}
