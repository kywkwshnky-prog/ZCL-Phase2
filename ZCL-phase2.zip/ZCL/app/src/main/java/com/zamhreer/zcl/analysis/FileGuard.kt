package com.zamhreer.zcl.analysis

import java.io.InputStream
import java.security.MessageDigest
import java.util.concurrent.CancellationException
import java.util.zip.ZipInputStream

/** Indicator-based file inspection. Files are only read as bytes; nothing is ever executed. */
object FileGuard {
    const val RULES_VERSION = "ZCL-FILE-1.0.0"
    private const val MAX_ENTRIES = 5000
    private const val MAX_UNCOMPRESSED = 256L * 1024 * 1024
    private const val PDF_SCAN_LIMIT = 8L * 1024 * 1024
    val LIMITS = listOf(
        "يفحص مؤشرات محددة فقط (نوع الملف، الامتداد، البنية، الأرشيف، محتوى PDF النشط) وليس محرك مضاد فيروسات.",
        "عدم ظهور مؤشرات لا يعني أن الملف سليم.",
        "لا يُنفَّذ الملف ولا يُرسل إلى أي خدمة خارجية.",
        "فحص الأرشيف محدود بـ $MAX_ENTRIES عنصر و${MAX_UNCOMPRESSED / 1024 / 1024} ميغابايت بعد الفك، ولا يدخل الأرشيفات المتداخلة."
    )

    data class Report(val name: String, val size: Long, val type: String, val sha256: String,
                      val sha512: String, val findings: List<Finding>) {
        val verdict: String get() = when (findings.maxOfOrNull { it.severity.weight } ?: 0) {
            in 35..100 -> "مؤشرات خطر — يُنصح بعدم الفتح"
            in 15..34 -> "مؤشرات تستحق المراجعة"
            in 1..14 -> "ملاحظات بسيطة"
            else -> "لم تُكتشف مؤشرات ضمن حدود الفحص"
        }
    }

    private class Sig(val type: String, val exts: Set<String>, val exec: Boolean = false)

    private fun detect(h: ByteArray): Sig? {
        fun starts(vararg b: Int) = h.size >= b.size && b.indices.all { (h[it].toInt() and 0xFF) == b[it] }
        return when {
            starts(0x25, 0x50, 0x44, 0x46) -> Sig("PDF", setOf("pdf"))
            starts(0x89, 0x50, 0x4E, 0x47) -> Sig("PNG", setOf("png"))
            starts(0xFF, 0xD8, 0xFF) -> Sig("JPEG", setOf("jpg", "jpeg"))
            starts(0x47, 0x49, 0x46, 0x38) -> Sig("GIF", setOf("gif"))
            starts(0x52, 0x49, 0x46, 0x46) && h.size >= 12 && h[8].toInt() == 0x57 && h[9].toInt() == 0x45 -> Sig("WEBP", setOf("webp"))
            starts(0x50, 0x4B, 0x03, 0x04) -> Sig("ZIP/Office/APK/JAR", setOf("zip", "docx", "xlsx", "pptx", "apk", "jar", "odt", "ods", "epub", "aab"))
            starts(0x52, 0x61, 0x72, 0x21) -> Sig("RAR", setOf("rar"))
            starts(0x37, 0x7A, 0xBC, 0xAF) -> Sig("7-Zip", setOf("7z"))
            starts(0x1F, 0x8B) -> Sig("GZIP", setOf("gz", "tgz"))
            starts(0x7F, 0x45, 0x4C, 0x46) -> Sig("ELF تنفيذي", setOf("so", "elf", "bin", "o"), true)
            starts(0x4D, 0x5A) -> Sig("Windows PE تنفيذي", setOf("exe", "dll", "sys", "scr", "ocx"), true)
            starts(0x64, 0x65, 0x78, 0x0A) -> Sig("Android DEX", setOf("dex"), true)
            starts(0x23, 0x21) -> Sig("سكربت (#!)", setOf("sh", "py", "pl", "rb", "bash"), true)
            else -> null
        }
    }

    private val scriptExts = setOf("exe", "dll", "scr", "bat", "cmd", "vbs", "js", "jse", "wsf", "ps1", "sh", "jar", "apk", "msi", "com", "lnk", "hta")
    private val archiveExts = setOf("zip", "rar", "7z", "gz", "tgz", "jar", "apk")
    private val pdfTokens = listOf("/JavaScript", "/JS", "/Launch", "/OpenAction", "/EmbeddedFile", "/AA", "/RichMedia")

    private fun f(id: String, t: String, s: Severity, c: String, ev: String, why: String, fix: String) =
        Finding(id, t, s, c, ev, why, fix)

    fun analyze(name: String, open: () -> InputStream, progress: (Long) -> Unit = {}, cancelled: () -> Boolean = { false }): Report {
        val findings = mutableListOf<Finding>()
        val ext = name.substringAfterLast('.', "").lowercase()
        val sha256 = MessageDigest.getInstance("SHA-256")
        val sha512 = MessageDigest.getInstance("SHA-512")
        val head = ByteArray(16); var headLen = 0
        var total = 0L
        var tail = ""
        val pdfHits = linkedSetOf<String>()
        var isPdf = false

        open().use { ins ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                if (cancelled()) throw CancellationException("cancelled")
                val n = ins.read(buf)
                if (n < 0) break
                sha256.update(buf, 0, n); sha512.update(buf, 0, n)
                if (headLen < 16) {
                    val c = minOf(16 - headLen, n)
                    System.arraycopy(buf, 0, head, headLen, c); headLen += c
                    if (headLen >= 4 && head[0].toInt() == 0x25 && head[1].toInt() == 0x50 && head[2].toInt() == 0x44 && head[3].toInt() == 0x46) isPdf = true
                }
                if (isPdf && total < PDF_SCAN_LIMIT) {
                    val window = tail + String(buf, 0, n, Charsets.ISO_8859_1)
                    pdfTokens.forEach { if (window.contains(it)) pdfHits += it }
                    tail = window.takeLast(24)
                }
                total += n
                progress(total)
            }
        }

        val sig = detect(head.copyOf(headLen))
        val typeName = sig?.type ?: "غير محدد (نص/بيانات)"

        if (total == 0L) findings += f("FG-EMPTY", "ملف فارغ", Severity.MEDIUM, "عالية", "0 بايت", "قد يكون تالفاً أو لم يكتمل تنزيله.", "أعد تنزيله.")
        if (name.contains('\u202E')) findings += f("FG-RTLO", "حرف عكس الاتجاه (RTLO) في الاسم", Severity.HIGH, "عالية", name.replace('\u202E', '⟲'),
            "يُستخدم لإخفاء الامتداد الحقيقي للملف.", "لا تفتح الملف.")
        if (Regex("""\.(pdf|docx?|xlsx?|jpe?g|png|txt|zip|mp4)\.(exe|scr|bat|cmd|js|vbs|apk|jar|com|ps1|hta)$""", RegexOption.IGNORE_CASE).containsMatchIn(name))
            findings += f("FG-DOUBLE", "امتداد مزدوج مخادع", Severity.HIGH, "عالية", name, "يبدو كمستند وهو ملف تنفيذي.", "لا تفتحه.")
        if (sig != null && ext.isNotEmpty() && ext !in sig.exts) {
            if (sig.exec) findings += f("FG-EXEC-MISMATCH", "ملف تنفيذي بامتداد غير تنفيذي", Severity.HIGH, "عالية", "النوع الفعلي: ${sig.type} / الامتداد: .$ext",
                "إخفاء ملف تنفيذي خلف امتداد عادي.", "لا تفتحه إلا إن كنت متأكداً من مصدره.")
            else findings += f("FG-MISMATCH", "الامتداد لا يطابق النوع الفعلي", Severity.MEDIUM, "عالية", "النوع الفعلي: ${sig.type} / الامتداد: .$ext",
                "قد يكون الملف مُعاد تسميته أو تالفاً.", "تحقق من مصدره.")
        } else if (sig != null && ext.isEmpty() && sig.exec) {
            findings += f("FG-EXEC", "ملف تنفيذي", Severity.MEDIUM, "عالية", sig.type, "قابل للتشغيل.", "لا تشغله إلا من مصدر موثوق.")
        }
        if (ext in scriptExts && sig?.exec != true)
            findings += f("FG-SCRIPT", "امتداد قابل للتنفيذ/سكربت (.$ext)", Severity.LOW, "عالية", name, "قد ينفذ أوامر عند فتحه.", "افتحه كنص فقط ما لم تثق به.")
        if (isPdf && pdfHits.isNotEmpty()) {
            val active = pdfHits.any { it == "/JavaScript" || it == "/JS" || it == "/Launch" || it == "/RichMedia" }
            findings += f("FG-PDF", "محتوى نشط في PDF", if (active) Severity.MEDIUM else Severity.LOW, "متوسطة", pdfHits.joinToString(),
                "عناصر كجافاسكربت أو إطلاق برامج أو ملفات مدمجة تُستخدم أحياناً في هجمات، وقد تكون مشروعة.", "افتحه في قارئ محدث وعطّل JavaScript.")
        }

        val isZip = sig?.type?.startsWith("ZIP") == true
        if (isZip) scanZip(open, total, findings, cancelled)
        else if (ext in archiveExts && sig == null)
            findings += f("FG-ARCH-UNKNOWN", "أرشيف بصيغة غير مقروءة", Severity.INFO, "منخفضة", ".$ext", "لم يتعرف الفاحص على ترويسته.", "افحصه بأداة مختصة.")

        return Report(name, total, typeName, sha256.digest().hex(), sha512.digest().hex(),
            findings.sortedByDescending { it.severity.weight })
    }

    private fun ByteArray.hex() = joinToString("") { "%02x".format(it) }

    private fun scanZip(open: () -> InputStream, fileSize: Long, out: MutableList<Finding>, cancelled: () -> Boolean) {
        val dangerous = linkedSetOf<String>()
        val traversal = linkedSetOf<String>()
        val nested = linkedSetOf<String>()
        var entries = 0; var unc = 0L
        var macros = false; var apk = false
        try {
            ZipInputStream(open()).use { z ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val e = z.nextEntry ?: break
                    entries++
                    if (entries > MAX_ENTRIES) {
                        out += f("FG-ZIP-ENTRIES", "عدد عناصر الأرشيف كبير جداً", Severity.HIGH, "عالية", "> $MAX_ENTRIES", "قد يكون قنبلة أرشيف.", "لا تفكه."); return
                    }
                    val n = e.name
                    if (n.contains("..") || n.startsWith("/") || Regex("""^[A-Za-z]:[\\/]""").containsMatchIn(n)) traversal += n
                    val x = n.substringAfterLast('.', "").lowercase()
                    if (x in setOf("exe", "dll", "scr", "bat", "cmd", "vbs", "ps1", "hta", "msi", "lnk", "so", "dex", "sh")) dangerous += n
                    if (x in archiveExts) nested += n
                    if (n.endsWith("vbaProject.bin", true)) macros = true
                    if (n == "AndroidManifest.xml" || n == "classes.dex") apk = true
                    while (true) {
                        if (cancelled()) throw CancellationException("cancelled")
                        val r = z.read(buf)
                        if (r < 0) break
                        unc += r
                        if (unc > MAX_UNCOMPRESSED) {
                            out += f("FG-ZIP-BOMB", "حجم الفك كبير جداً", Severity.HIGH, "عالية", ">${MAX_UNCOMPRESSED / 1024 / 1024} MB",
                                "قد يكون قنبلة ضغط تستنزف الذاكرة والتخزين.", "لا تفك هذا الأرشيف."); return
                        }
                    }
                }
            }
        } catch (e: CancellationException) { throw e } catch (e: Exception) {
            out += f("FG-ZIP-CORRUPT", "أرشيف تالف أو غير قابل للقراءة", Severity.MEDIUM, "متوسطة", e.message?.take(80) ?: "", "بنية الأرشيف غير سليمة.", "أعد تنزيله.")
            return
        }
        if (fileSize > 0 && unc / fileSize > 200 && unc > 50L * 1024 * 1024)
            out += f("FG-ZIP-RATIO", "نسبة ضغط مرتفعة جداً", Severity.HIGH, "متوسطة", "x${unc / fileSize}", "مؤشر على قنبلة ضغط.", "لا تفكه.")
        if (traversal.isNotEmpty()) out += f("FG-ZIP-TRAVERSAL", "مسارات خطرة داخل الأرشيف (Zip Slip)", Severity.HIGH, "عالية",
            traversal.take(5).joinToString(), "قد تكتب خارج مجلد الفك.", "لا تفكه بأدوات لا تتحقق من المسارات.")
        if (dangerous.isNotEmpty()) out += f("FG-ZIP-EXEC", "ملفات قابلة للتنفيذ داخل الأرشيف (${dangerous.size})", Severity.MEDIUM, "عالية",
            dangerous.take(8).joinToString(), "الأرشيف يحوي تنفيذيات/سكربتات.", "لا تشغلها إلا من مصدر موثوق.")
        if (nested.isNotEmpty()) out += f("FG-ZIP-NESTED", "أرشيفات متداخلة", Severity.LOW, "عالية", nested.take(5).joinToString(), "لم تُفحص من الداخل.", "افحصها منفصلة.")
        if (macros) out += f("FG-OFFICE-MACRO", "مستند Office يحتوي ماكرو (vbaProject)", Severity.MEDIUM, "عالية", "vbaProject.bin", "الماكرو قد ينفذ أوامر.", "لا تفعّل الماكرو إلا من مصدر موثوق.")
        if (apk) out += f("FG-APK", "حزمة تطبيق Android", Severity.INFO, "عالية", "AndroidManifest.xml/classes.dex", "ملف تثبيت تطبيق.", "ثبّته من مصادر رسمية فقط.")
    }
}
