package com.zamhreer.zcl.analysis

import okhttp3.Dns
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.security.cert.X509Certificate
import java.util.concurrent.CancellationException
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLException

/** Passive website configuration check: a few GET requests, no exploitation, no body download. */
object ZScan {
    const val RULES_VERSION = "ZCL-WEB-1.0.0"
    private const val MAX_REDIRECTS = 5
    val LIMITS = listOf(
        "فحص سلبي لإعدادات HTTPS والترويسات والكوكيز عبر طلبات GET عادية (حد أقصى 6 طلبات). لا استغلال ولا تخمين.",
        "لا يفحص ثغرات التطبيق نفسه (SQLi/XSS…) ولا يقرأ جسم الصفحة.",
        "اجتياز الفحوصات المحددة لا يعني أن الموقع آمن بالكامل.",
        "يُحجب أي هدف يشير إلى عنوان داخلي/خاص (حماية SSRF) ويُعاد التحقق عند كل اتصال وكل إعادة توجيه.",
        "مهلة الاتصال 8 ثوانٍ، وتُفرض فترة انتظار 5 ثوانٍ بين كل فحصين."
    )

    data class Result(val target: String, val status: String, val verdict: String, val finalUrl: String,
                      val httpCode: Int, val latencyMs: Long, val tlsInfo: List<String>,
                      val findings: List<Finding>, val chain: List<String>)

    @Volatile private var last = 0L

    private fun f(id: String, t: String, s: Severity, c: String, ev: String, why: String, fix: String) = Finding(id, t, s, c, ev, why, fix)

    fun verdictFor(findings: List<Finding>): String = when (findings.maxOfOrNull { it.severity.weight } ?: 0) {
        in 35..100 -> "خطر في الإعدادات — يحتاج إصلاحاً"
        in 15..34 -> "ملاحظات تحتاج مراجعة"
        in 1..14 -> "ملاحظات بسيطة"
        else -> "اجتاز الفحوصات المحددة (لا يعني أن الموقع آمن بالكامل)"
    }

    /** Pure function (unit-testable): headers keys must be lower-case. */
    fun evaluateHeaders(h: Map<String, String>, setCookies: List<String>, https: Boolean): List<Finding> {
        val out = mutableListOf<Finding>()
        val csp = h["content-security-policy"]
        if (csp == null) out += f("WEB-CSP", "غياب Content-Security-Policy", Severity.MEDIUM, "عالية", "الترويسة غير موجودة",
            "CSP تقلل أثر XSS وحقن المحتوى.", "أضف CSP صارمة (default-src 'self').")
        else if (Regex("unsafe-(inline|eval)").containsMatchIn(csp))
            out += f("WEB-CSP-WEAK", "CSP تسمح بـ unsafe-inline/eval", Severity.LOW, "عالية", csp.take(120), "تُضعف الحماية.", "استبدلها بـ nonce أو hash.")
        if (https) {
            val hsts = h["strict-transport-security"]
            if (hsts == null) out += f("WEB-HSTS", "غياب Strict-Transport-Security", Severity.MEDIUM, "عالية", "الترويسة غير موجودة",
                "تجبر المتصفح على HTTPS وتمنع هجمات خفض الحماية.", "أضف HSTS بـ max-age لا يقل عن 15552000.")
            else {
                val age = Regex("max-age=(\\d+)").find(hsts)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
                if (age < 15552000L) out += f("WEB-HSTS-SHORT", "مدة HSTS قصيرة", Severity.LOW, "عالية", hsts, "المدة أقل من 180 يوماً.", "ارفع max-age.")
            }
        }
        if (h["x-content-type-options"]?.lowercase() != "nosniff")
            out += f("WEB-XCTO", "غياب X-Content-Type-Options: nosniff", Severity.LOW, "عالية", "", "يمنع تخمين نوع المحتوى.", "أضف nosniff.")
        if (h["referrer-policy"] == null)
            out += f("WEB-REFERRER", "غياب Referrer-Policy", Severity.LOW, "عالية", "", "قد تتسرب عناوين داخلية للمواقع الأخرى.", "أضف strict-origin-when-cross-origin.")
        if (h["x-frame-options"] == null && csp?.contains("frame-ancestors") != true)
            out += f("WEB-FRAME", "لا حماية من التضمين (Clickjacking)", Severity.MEDIUM, "عالية", "لا X-Frame-Options ولا frame-ancestors",
                "يمكن تضمين الصفحة داخل موقع خبيث.", "أضف frame-ancestors 'self' أو X-Frame-Options: DENY.")
        if (h["permissions-policy"] == null)
            out += f("WEB-PERMS", "غياب Permissions-Policy", Severity.INFO, "عالية", "", "تقييد ميزات المتصفح (كاميرا/موقع).", "أضفها إن كانت مناسبة.")
        h["server"]?.let { if (Regex("\\d").containsMatchIn(it)) out += f("WEB-SERVER", "كشف إصدار الخادم", Severity.LOW, "عالية", it.take(60), "يسهّل استهداف إصدارات معروفة.", "أخفِ رقم الإصدار.") }
        h["x-powered-by"]?.let { out += f("WEB-POWERED", "ترويسة X-Powered-By", Severity.LOW, "عالية", it.take(60), "تكشف التقنية المستخدمة.", "أزلها.") }
        if (h["access-control-allow-origin"] == "*") {
            if (h["access-control-allow-credentials"]?.lowercase() == "true")
                out += f("WEB-CORS", "CORS: * مع credentials", Severity.HIGH, "عالية", "", "تركيبة غير صالحة وخطرة.", "حدد أصولاً صريحة.")
            else out += f("WEB-CORS-OPEN", "CORS مفتوح لكل الأصول", Severity.INFO, "عالية", "", "مقبول لمحتوى عام فقط.", "تأكد أنه مقصود.")
        }
        val noSecure = linkedSetOf<String>(); val noHttpOnly = linkedSetOf<String>(); val noSame = linkedSetOf<String>()
        setCookies.forEach { c ->
            val name = c.substringBefore('=').trim().take(40)
            val low = c.lowercase()
            if (https && !low.contains("; secure") && !low.endsWith(";secure")) noSecure += name
            if (!low.contains("httponly")) noHttpOnly += name
            if (!low.contains("samesite")) noSame += name
        }
        if (noSecure.isNotEmpty()) out += f("WEB-COOKIE-SECURE", "كوكيز بدون Secure", Severity.MEDIUM, "عالية", noSecure.joinToString(), "قد تُرسل عبر HTTP.", "أضف Secure.")
        if (noHttpOnly.isNotEmpty()) out += f("WEB-COOKIE-HTTPONLY", "كوكيز بدون HttpOnly", Severity.LOW, "متوسطة", noHttpOnly.joinToString(), "قد تُقرأ عبر JavaScript (قد تكون مقصودة).", "أضف HttpOnly لكوكيز الجلسة.")
        if (noSame.isNotEmpty()) out += f("WEB-COOKIE-SAMESITE", "كوكيز بدون SameSite", Severity.LOW, "متوسطة", noSame.joinToString(), "تزيد خطر CSRF.", "أضف SameSite=Lax أو Strict.")
        return out
    }

    private fun fail(target: String, msg: String, extra: Finding? = null) =
        Result(target, msg, "تعذر الفحص", "", 0, 0, emptyList(), listOfNotNull(extra), emptyList())

    fun scan(input: String, cancelled: () -> Boolean = { false }): Result {
        val now = System.currentTimeMillis()
        if (now - last < 5000) return fail(input, "انتظر 5 ثوانٍ بين كل فحص وآخر (تقييد الطلبات).")
        last = now
        var raw = input.trim()
        if (raw.isEmpty()) return fail(input, "أدخل عنواناً.")
        if (!raw.contains("://")) raw = "https://$raw"
        var url = raw.toHttpUrlOrNull() ?: return fail(input, "عنوان غير صالح.")
        val startedHttp = url.scheme == "http"

        val dns = object : Dns {
            override fun lookup(hostname: String): List<InetAddress> {
                val all = InetAddress.getAllByName(hostname).toList()
                if (all.isEmpty() || all.any { NetGuard.isBlocked(it) }) throw UnknownHostException("blocked")
                return all
            }
        }
        val client = OkHttpClient.Builder().dns(dns).followRedirects(false).followSslRedirects(false)
            .connectTimeout(8, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).callTimeout(15, TimeUnit.SECONDS).build()

        val chain = mutableListOf<String>()
        var redirects = 0
        var headers: Map<String, String> = emptyMap()
        var cookies: List<String> = emptyList()
        var code = 0; var latency = 0L; var cert: X509Certificate? = null; var finalHttps = false
        var redirectedToHttps = false

        try {
            while (true) {
                if (cancelled()) throw CancellationException("cancelled")
                if (NetGuard.hostBlocked(url.host) || url.port !in setOf(80, 443))
                    return fail(input, "تم حجب الهدف", f("WEB-BLOCKED", "هدف محجوب (حماية SSRF)", Severity.INFO, "عالية", url.host,
                        "الفاحص لا يتصل بعناوين داخلية/خاصة أو منافذ غير 80/443.", "استخدم Z-Net لفحص شبكتك المحلية."))
                chain += url.toString()
                val req = Request.Builder().url(url).header("User-Agent", "ZCL-Scanner/2.0 (+https://t.me/rtf60)").get().build()
                val t0 = System.nanoTime()
                var next: okhttp3.HttpUrl? = null
                client.newCall(req).execute().use { resp ->
                    latency = (System.nanoTime() - t0) / 1_000_000
                    code = resp.code
                    finalHttps = resp.request.url.scheme == "https"
                    cert = resp.handshake?.peerCertificates?.firstOrNull() as? X509Certificate
                    if (resp.isRedirect) {
                        next = resp.header("Location")?.let { resp.request.url.resolve(it) }
                        if (next?.scheme == "https" && url.scheme == "http" && redirects == 0) redirectedToHttps = true
                    } else {
                        val m = linkedMapOf<String, String>()
                        resp.headers.names().forEach { n -> resp.headers[n]?.let { m[n.lowercase()] = it } }
                        headers = m
                        cookies = resp.headers("Set-Cookie")
                    }
                }
                val n = next ?: break
                redirects++
                if (redirects > MAX_REDIRECTS) return fail(input, "عدد إعادة التوجيه تجاوز $MAX_REDIRECTS.")
                url = n
            }
        } catch (e: CancellationException) { throw e
        } catch (e: SSLException) {
            return fail(input, "فشل التحقق من شهادة TLS", f("WEB-TLS-FAIL", "شهادة TLS غير صالحة أو غير موثوقة", Severity.HIGH, "عالية",
                e.message?.take(120) ?: "", "فشل التحقق ولم يُعطَّل (قد تكون الشهادة منتهية/منتحلة/غير موثوقة).", "أصلح الشهادة قبل أي شيء."))
        } catch (e: UnknownHostException) {
            return if (e.message == "blocked") fail(input, "تم حجب الهدف", f("WEB-BLOCKED", "الاسم يشير إلى عنوان داخلي/خاص", Severity.INFO, "عالية", url.host,
                "حماية SSRF.", "استخدم Z-Net للشبكة المحلية.")) else fail(input, "تعذر حل اسم النطاق (DNS).")
        } catch (e: SocketTimeoutException) { return fail(input, "انتهت مهلة الاتصال.")
        } catch (e: IOException) { return fail(input, "خطأ اتصال: ${e.message?.take(80)}") }

        val findings = mutableListOf<Finding>()
        val tls = mutableListOf<String>()
        if (startedHttp) {
            if (!redirectedToHttps) findings += f("WEB-NOREDIR", "لا إعادة توجيه من HTTP إلى HTTPS", Severity.MEDIUM, "عالية", "http://", "الزائر قد يبقى بلا تشفير.", "أضف تحويل 301 إلى HTTPS.")
        }
        if (!finalHttps) findings += f("WEB-NOHTTPS", "الموقع يعمل بدون HTTPS", Severity.HIGH, "عالية", url.toString(), "الاتصال غير مشفّر.", "فعّل HTTPS.")
        cert?.let { c ->
            val days = TimeUnit.MILLISECONDS.toDays(c.notAfter.time - System.currentTimeMillis())
            tls += "الجهة المصدرة: ${c.issuerX500Principal.name.take(100)}"
            tls += "تنتهي في: ${c.notAfter} (متبقي $days يوماً)"
            tls += "التحقق من السلسلة: نجح (التحقق غير معطّل)"
            if (days < 0) findings += f("WEB-CERT-EXPIRED", "الشهادة منتهية", Severity.CRITICAL, "عالية", "${c.notAfter}", "المتصفحات ستحذّر الزوار.", "جدد الشهادة.")
            else if (days < 14) findings += f("WEB-CERT-SOON", "الشهادة تنتهي قريباً ($days يوماً)", Severity.HIGH, "عالية", "${c.notAfter}", "خطر انقطاع.", "جدد الشهادة الآن.")
            else if (days < 30) findings += f("WEB-CERT-30", "الشهادة تنتهي خلال 30 يوماً", Severity.MEDIUM, "عالية", "${c.notAfter}", "", "فعّل التجديد التلقائي.")
        }
        if (code >= 500) findings += f("WEB-5XX", "الخادم يرد بخطأ $code", Severity.LOW, "عالية", "", "قد تكون الترويسات غير ممثلة.", "أعد الفحص لاحقاً.")
        findings += evaluateHeaders(headers, cookies, finalHttps)
        val sorted = findings.sortedByDescending { it.severity.weight }
        return Result(input, "اكتمل", verdictFor(sorted), url.toString(), code, latency, tls, sorted, chain)
    }
}
