package com.zamhreer.zcl.data

import android.content.Context

/** Minimal local operation counters. Starts at zero; only real operations will increment it. */
class LocalLog(context: Context) {
    private val prefs = context.getSharedPreferences("zcl_log", Context.MODE_PRIVATE)
    val completed: Int get() = prefs.getInt("completed", 0)
    val failed: Int get() = prefs.getInt("failed", 0)
    fun recordCompleted() = prefs.edit().putInt("completed", completed + 1).apply()
    fun recordFailed() = prefs.edit().putInt("failed", failed + 1).apply()
    fun clear() = prefs.edit().clear().apply()
}
