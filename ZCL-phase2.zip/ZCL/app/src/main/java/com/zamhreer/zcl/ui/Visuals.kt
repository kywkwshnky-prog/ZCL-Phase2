package com.zamhreer.zcl.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Cut-corner "tech frame" used for engine tiles. */
val HexShape = GenericShape { size, _ ->
    val c = size.minDimension * 0.16f
    moveTo(c, 0f); lineTo(size.width - c, 0f); lineTo(size.width, c)
    lineTo(size.width, size.height - c); lineTo(size.width - c, size.height)
    lineTo(c, size.height); lineTo(0f, size.height - c); lineTo(0f, c); close()
}

@Composable
fun ZclBackground() {
    val reduced = LocalReducedMotion.current
    val tr = rememberInfiniteTransition(label = "bg")
    val anim by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(8000, easing = LinearEasing)), label = "scan")
    val t = if (reduced) 0.35f else anim
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(Zcl.Void, Color(0xFF041022), Zcl.Void)))
        val step = 44.dp.toPx()
        var x = 0f
        while (x < size.width) { drawLine(Zcl.Cyan.copy(alpha = .045f), Offset(x, 0f), Offset(x, size.height)); x += step }
        var y = 0f
        while (y < size.height) { drawLine(Zcl.Cyan.copy(alpha = .045f), Offset(0f, y), Offset(size.width, y)); y += step }
        val center = Offset(size.width / 2, size.height * 0.16f)
        drawCircle(Brush.radialGradient(listOf(Zcl.Cyan.copy(alpha = .20f), Color.Transparent), center = center, radius = size.width * 0.9f),
            radius = size.width * 0.9f, center = center)
        val sy = size.height * t
        val band = 140f
        drawRect(Brush.verticalGradient(listOf(Color.Transparent, Zcl.Cyan.copy(alpha = .10f), Color.Transparent), startY = sy - band, endY = sy + band),
            topLeft = Offset(0f, sy - band), size = Size(size.width, band * 2))
    }
}
