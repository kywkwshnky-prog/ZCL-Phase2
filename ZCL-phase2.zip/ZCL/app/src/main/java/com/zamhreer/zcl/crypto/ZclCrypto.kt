package com.zamhreer.zcl.crypto

import com.google.crypto.tink.subtle.AesGcmHkdfStreaming
import java.io.*
import java.security.GeneralSecurityException
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.CancellationException
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class ZclCryptoException(message: String) : Exception(message)

sealed class Secret {
    class Password(val chars: CharArray) : Secret()
    class Key(val bytes: ByteArray) : Secret()
}

/**
 * ZCLE format v1 (all integers big-endian):
 *   "ZCLE" | version(1) | kdfId(1) | iterations(4) | saltLen(1) | salt | <Tink AES-256-GCM-HKDF stream>
 * kdfId 0 = raw 256-bit key (Z-KeySafe), 1 = PBKDF2-HMAC-SHA256.
 * The whole header is passed as associated data, so any header change makes decryption fail.
 * The body is Tink's AesGcmHkdfStreaming (4096-byte segments, per-segment nonce, ordering and
 * truncation detection built into the library format).
 */
object ZclCrypto {
    private val MAGIC = byteArrayOf(0x5A, 0x43, 0x4C, 0x45)
    private const val VERSION = 1
    const val KDF_KEY = 0
    const val KDF_PBKDF2 = 1
    const val DEFAULT_ITER = 600_000
    private const val MIN_ITER = 100_000
    private const val MAX_ITER = 5_000_000
    private const val SALT_LEN = 16
    private const val SEGMENT = 4096
    private val rng = SecureRandom()

    fun randomKey(): ByteArray = ByteArray(32).also { rng.nextBytes(it) }

    private fun deriveKey(password: CharArray, salt: ByteArray, iter: Int): ByteArray {
        val spec = PBEKeySpec(password, salt, iter, 256)
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    private fun buildHeader(kdf: Int, iter: Int, salt: ByteArray): ByteArray {
        val bos = ByteArrayOutputStream()
        val d = DataOutputStream(bos)
        d.write(MAGIC); d.writeByte(VERSION); d.writeByte(kdf)
        d.writeInt(iter); d.writeByte(salt.size); d.write(salt)
        d.flush()
        return bos.toByteArray()
    }

    private class Header(val kdf: Int, val iter: Int, val salt: ByteArray) {
        fun raw() = buildHeader(kdf, iter, salt)
    }

    private fun readHeader(input: InputStream): Header {
        val d = DataInputStream(input)
        try {
            val magic = ByteArray(4); d.readFully(magic)
            if (!magic.contentEquals(MAGIC)) throw ZclCryptoException("ليس ملفاً مشفراً بصيغة ZCL")
            if (d.readUnsignedByte() != VERSION) throw ZclCryptoException("إصدار الصيغة غير مدعوم")
            val kdf = d.readUnsignedByte()
            val iter = d.readInt()
            val saltLen = d.readUnsignedByte()
            if (saltLen > 64) throw ZclCryptoException("رأس الملف تالف")
            val salt = ByteArray(saltLen); d.readFully(salt)
            when (kdf) {
                KDF_PBKDF2 -> if (iter !in MIN_ITER..MAX_ITER || saltLen < 8) throw ZclCryptoException("إعدادات اشتقاق المفتاح غير مقبولة")
                KDF_KEY -> if (iter != 0 || saltLen != 0) throw ZclCryptoException("رأس الملف تالف")
                else -> throw ZclCryptoException("خوارزمية اشتقاق غير معروفة")
            }
            return Header(kdf, iter, salt)
        } catch (e: EOFException) {
            throw ZclCryptoException("الملف قصير أو تالف")
        }
    }

    private fun copy(src: InputStream, dst: OutputStream, readErrorIsAuth: Boolean,
                     progress: (Long) -> Unit, cancelled: () -> Boolean) {
        val buf = ByteArray(64 * 1024)
        var total = 0L
        while (true) {
            if (cancelled()) throw CancellationException("cancelled")
            val n = try {
                src.read(buf)
            } catch (e: IOException) {
                if (readErrorIsAuth) throw ZclCryptoException("فشل التحقق: كلمة المرور/المفتاح خاطئ أو الملف معدّل أو مقتطع")
                throw e
            }
            if (n < 0) break
            dst.write(buf, 0, n)
            total += n
            progress(total)
        }
    }

    fun encrypt(input: InputStream, output: OutputStream, secret: Secret,
                progress: (Long) -> Unit = {}, cancelled: () -> Boolean = { false }) {
        val header: ByteArray
        val ikm: ByteArray
        when (secret) {
            is Secret.Password -> {
                val salt = ByteArray(SALT_LEN).also { rng.nextBytes(it) }
                header = buildHeader(KDF_PBKDF2, DEFAULT_ITER, salt)
                ikm = deriveKey(secret.chars, salt, DEFAULT_ITER)
            }
            is Secret.Key -> {
                if (secret.bytes.size != 32) throw ZclCryptoException("المفتاح يجب أن يكون 256 بت")
                header = buildHeader(KDF_KEY, 0, ByteArray(0))
                ikm = secret.bytes
            }
        }
        output.write(header)
        val aead = AesGcmHkdfStreaming(ikm, "HmacSha256", 32, SEGMENT, 0)
        aead.newEncryptingStream(output, header).use { out ->
            copy(input, out, false, progress, cancelled)
        }
    }

    fun decrypt(input: InputStream, output: OutputStream, secret: Secret,
                progress: (Long) -> Unit = {}, cancelled: () -> Boolean = { false }) {
        val h = readHeader(input)
        val ikm = when (h.kdf) {
            KDF_PBKDF2 -> {
                if (secret !is Secret.Password) throw ZclCryptoException("هذا الملف مشفّر بكلمة مرور")
                deriveKey(secret.chars, h.salt, h.iter)
            }
            else -> {
                if (secret !is Secret.Key) throw ZclCryptoException("هذا الملف مشفّر بمفتاح من Z-KeySafe")
                if (secret.bytes.size != 32) throw ZclCryptoException("المفتاح يجب أن يكون 256 بت")
                secret.bytes
            }
        }
        val aead = AesGcmHkdfStreaming(ikm, "HmacSha256", 32, SEGMENT, 0)
        val ins = try {
            aead.newDecryptingStream(input, h.raw())
        } catch (e: GeneralSecurityException) {
            throw ZclCryptoException("فشل التحقق: كلمة المرور/المفتاح خاطئ أو الملف معدّل")
        } catch (e: IOException) {
            throw ZclCryptoException("فشل التحقق: الملف تالف")
        }
        ins.use { copy(it, output, true, progress, cancelled) }
    }

    fun encryptBytes(data: ByteArray, secret: Secret): ByteArray {
        val bos = ByteArrayOutputStream()
        encrypt(ByteArrayInputStream(data), bos, secret)
        return bos.toByteArray()
    }
}

object ZclHash {
    fun compute(input: InputStream, algorithm: String, progress: (Long) -> Unit = {},
                cancelled: () -> Boolean = { false }): String {
        require(algorithm == "SHA-256" || algorithm == "SHA-512")
        val md = MessageDigest.getInstance(algorithm)
        val buf = ByteArray(64 * 1024)
        var total = 0L
        while (true) {
            if (cancelled()) throw CancellationException("cancelled")
            val n = input.read(buf)
            if (n < 0) break
            md.update(buf, 0, n)
            total += n
            progress(total)
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}

object PassAudit {
    data class Result(val score: Int, val label: String, val tips: List<String>)

    private val common = setOf("password", "123456", "12345678", "123456789", "qwerty", "qwerty123", "111111",
        "abc123", "iloveyou", "admin", "welcome", "letmein", "monkey", "dragon", "football", "000000",
        "1234567890", "password1", "passw0rd", "p@ssw0rd", "zxcvbnm", "asdfghjkl", "1q2w3e4r", "اهلا", "حسن")
    private val seqs = listOf("0123456789", "abcdefghijklmnopqrstuvwxyz", "qwertyuiop", "asdfghjkl", "zxcvbnm")

    fun evaluate(p: String): Result {
        if (p.isEmpty()) return Result(0, "أدخل كلمة مرور", emptyList())
        val tips = mutableListOf<String>()
        val lower = p.lowercase()
        var pts = 0
        if (p.length >= 8) pts++
        if (p.length >= 12) pts++
        if (p.length >= 16) pts++
        val classes = listOf(p.any { it.isLowerCase() }, p.any { it.isUpperCase() },
            p.any { it.isDigit() }, p.any { !it.isLetterOrDigit() }).count { it }
        if (classes >= 3) pts++
        if (p.length < 12) tips += "استخدم 12 حرفاً فأكثر، أو عبارة سرية طويلة من عدة كلمات."
        if (classes < 3 && p.length < 16) tips += "نوّع بين الأحرف والأرقام والرموز."
        var capped = false
        if (lower in common) { capped = true; tips += "هذه من كلمات المرور الشائعة جداً." }
        if (p.toSet().size <= 2) { capped = true; tips += "حروف متكررة." }
        if (p.all { it.isDigit() }) { pts = minOf(pts, 1); tips += "أرقام فقط." }
        if (seqs.any { s -> (0..s.length - 4).any { i -> lower.contains(s.substring(i, i + 4)) } }) {
            pts = minOf(pts, 2); tips += "تحتوي تسلسلاً متوقعاً (مثل 1234 أو qwer)."
        }
        val score = if (capped) 0 else pts.coerceIn(0, 4)
        val label = listOf("ضعيفة جداً", "ضعيفة", "متوسطة", "جيدة", "قوية")[score]
        return Result(score, label, tips)
    }

    fun generate(length: Int = 20): String {
        val alphabet = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%^&*-_=+"
        val r = SecureRandom()
        return (1..length).map { alphabet[r.nextInt(alphabet.length)] }.joinToString("")
    }
}
