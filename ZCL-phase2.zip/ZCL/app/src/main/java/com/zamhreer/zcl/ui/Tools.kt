package com.zamhreer.zcl.ui

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zamhreer.zcl.crypto.*
import com.zamhreer.zcl.data.KeySafe
import com.zamhreer.zcl.data.LocalLog
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CancellationException

private fun queryName(ctx: Context, uri: Uri): String {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && i >= 0) return c.getString(i) ?: "file"
    }
    return "file"
}

private fun querySize(ctx: Context, uri: Uri): Long {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.SIZE)
        if (c.moveToFirst() && i >= 0 && !c.isNull(i)) return c.getLong(i)
    }
    return 0L
}

private fun fmtSize(b: Long) = when {
    b >= 1L shl 30 -> "%.2f GB".format(b / 1073741824.0)
    b >= 1L shl 20 -> "%.2f MB".format(b / 1048576.0)
    b >= 1L shl 10 -> "%.1f KB".format(b / 1024.0)
    else -> "$b B"
}

@Composable
private fun ToolScreen(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Zcl.Void).statusBarsPadding().navigationBarsPadding()
        .verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Zcl.Cyan, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            OutlinedButton(onBack) { Text("رجوع") }
        }
        content()
    }
}

@Composable private fun Note(t: String, c: androidx.compose.ui.graphics.Color = Zcl.Graphite) = Text(t, color = c, fontSize = 12.sp)

@Composable
private fun Progress(done: Long, total: Long) {
    if (total > 0) LinearProgressIndicator(progress = { (done.toFloat() / total).coerceIn(0f, 1f) }, color = Zcl.Cyan, modifier = Modifier.fillMaxWidth())
    else LinearProgressIndicator(color = Zcl.Cyan, modifier = Modifier.fillMaxWidth())
}

// ---------------- Z-Hash ----------------
@Composable
fun HashScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val log = remember { LocalLog(ctx) }
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    var uri by remember { mutableStateOf<Uri?>(null) }
    var algo by remember { mutableStateOf("SHA-256") }
    var result by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var done by remember { mutableLongStateOf(0L) }
    var total by remember { mutableLongStateOf(0L) }
    var job by remember { mutableStateOf<Job?>(null) }
    var ref by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { uri = u; result = ""; status = ""; total = querySize(ctx, u) }
    }
    ToolScreen("Z-Hash — بصمات الملفات", onBack) {
        Button({ picker.launch(arrayOf("*/*")) }) { Text("اختيار ملف") }
        uri?.let { Text("${queryName(ctx, it)}  (${fmtSize(total)})", color = Zcl.Ice, fontSize = 13.sp) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(algo == "SHA-256", { algo = "SHA-256" }, { Text("SHA-256") })
            FilterChip(algo == "SHA-512", { algo = "SHA-512" }, { Text("SHA-512") })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = uri != null && job?.isActive != true, onClick = {
                val u = uri ?: return@Button
                done = 0; result = ""; status = "جارٍ الحساب…"
                job = scope.launch {
                    try {
                        val h = withContext(Dispatchers.IO) {
                            val input = ctx.contentResolver.openInputStream(u) ?: throw java.io.IOException("تعذر فتح الملف")
                            input.use { ZclHash.compute(it, algo, { p -> done = p }, { !isActive }) }
                        }
                        result = h; status = "اكتمل"; log.recordCompleted()
                    } catch (e: CancellationException) {
                        status = "أُلغيت العملية"; log.recordFailed()
                    } catch (e: Exception) {
                        status = "فشلت العملية: ${e.message}"; log.recordFailed()
                    }
                }
            }) { Text("احسب البصمة") }
            if (job?.isActive == true) OutlinedButton({ job?.cancel() }) { Text("إلغاء") }
        }
        if (job?.isActive == true) Progress(done, total)
        if (status.isNotEmpty()) Note(status, Zcl.Ice)
        if (result.isNotEmpty()) {
            SelectionContainer { Text(result, color = Zcl.Cyan, fontSize = 12.sp) }
            OutlinedButton({ clip.setText(AnnotatedString(result)) }) { Text("نسخ") }
            OutlinedTextField(ref, { ref = it.trim() }, label = { Text("بصمة مرجعية للمقارنة") }, modifier = Modifier.fillMaxWidth())
            if (ref.isNotEmpty()) {
                if (ref.equals(result, ignoreCase = true)) Note("مطابقة للبصمة المرجعية", Zcl.Green)
                else Note("مختلفة عن البصمة المرجعية", Zcl.Red)
            }
        }
        Note("تطابق البصمة لا يثبت وحده سلامة الملف أو موثوقية مصدره؛ تأكد أن البصمة المرجعية جاءت من مصدر موثوق.")
    }
}

// ---------------- Z-Encrypt ----------------
@Composable
fun CryptoScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val log = remember { LocalLog(ctx) }
    val keySafe = remember { KeySafe(ctx) }
    val scope = rememberCoroutineScope()
    var encrypt by remember { mutableStateOf(true) }
    var useKey by remember { mutableStateOf(false) }
    var src by remember { mutableStateOf<Uri?>(null) }
    var size by remember { mutableLongStateOf(0L) }
    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var keyName by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("") }
    var done by remember { mutableLongStateOf(0L) }
    var job by remember { mutableStateOf<Job?>(null) }
    val keys = remember { keySafe.list() }

    fun run(dst: Uri) {
        val s = src ?: return
        val secret: Secret = if (useKey) {
            val k = keyName?.let { keySafe.get(it) }
            if (k == null) { status = "تعذر قراءة المفتاح"; return }
            Secret.Key(k)
        } else Secret.Password(pass.toCharArray())
        done = 0; status = "جارٍ التنفيذ…"
        job = scope.launch {
            var ok = false
            try {
                withContext(Dispatchers.IO) {
                    val tmp = File.createTempFile("zcl", ".tmp", ctx.cacheDir)
                    try {
                        val input = ctx.contentResolver.openInputStream(s) ?: throw java.io.IOException("تعذر فتح الملف")
                        input.use { ins ->
                            FileOutputStream(tmp).use { out ->
                                if (encrypt) ZclCrypto.encrypt(ins, out, secret, { done = it }, { !isActive })
                                else ZclCrypto.decrypt(ins, out, secret, { done = it }, { !isActive })
                            }
                        }
                        // Output is released only after full, successful verification.
                        val o = ctx.contentResolver.openOutputStream(dst, "wt") ?: throw java.io.IOException("تعذر الكتابة")
                        o.use { w -> tmp.inputStream().use { it.copyTo(w) } }
                    } finally { tmp.delete() }
                }
                ok = true
                status = if (encrypt) "تم التشفير بنجاح. الملف الأصلي لم يُعدَّل." else "تم فك التشفير والتحقق من سلامة الملف."
                log.recordCompleted()
            } catch (e: CancellationException) {
                status = "أُلغيت العملية"; log.recordFailed()
            } catch (e: ZclCryptoException) {
                status = e.message ?: "فشل التحقق"; log.recordFailed()
            } catch (e: Exception) {
                status = "فشلت العملية (قد تكون المساحة ممتلئة): ${e.message}"; log.recordFailed()
            } finally {
                if (!ok) runCatching { DocumentsContract.deleteDocument(ctx.contentResolver, dst) }
                pass = ""; pass2 = ""
            }
        }
    }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { dst ->
        if (dst != null) run(dst) else status = "لم يُحدَّد مكان الحفظ"
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { src = u; size = querySize(ctx, u); status = "" }
    }
    val passOk = pass.length >= 8 && (!encrypt || pass == pass2)
    val ready = src != null && job?.isActive != true && (if (useKey) keyName != null else passOk)

    ToolScreen("Z-Encrypt — تشفير الملفات", onBack) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(encrypt, { encrypt = true }, { Text("تشفير") })
            FilterChip(!encrypt, { encrypt = false }, { Text("فك التشفير") })
        }
        Button({ picker.launch(arrayOf("*/*")) }) { Text("اختيار ملف") }
        src?.let { Text("${queryName(ctx, it)}  (${fmtSize(size)})", color = Zcl.Ice, fontSize = 13.sp) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(!useKey, { useKey = false }, { Text("كلمة مرور") })
            FilterChip(useKey, { useKey = true }, { Text("مفتاح Z-KeySafe") })
        }
        if (!useKey) {
            OutlinedTextField(pass, { pass = it }, label = { Text("كلمة المرور (8 أحرف فأكثر)") },
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
            if (encrypt) OutlinedTextField(pass2, { pass2 = it }, label = { Text("تأكيد كلمة المرور") },
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
        } else if (keys.isEmpty()) Note("لا توجد مفاتيح. أنشئ مفتاحاً من Z-KeySafe أولاً.", Zcl.Amber)
        else keys.forEach { k -> FilterChip(keyName == k, { keyName = k }, { Text(k) }) }
        Button(enabled = ready, onClick = {
            val n = queryName(ctx, src!!)
            val out = if (encrypt) "$n.zcle" else n.removeSuffix(".zcle").let { if (it == n) "$n.dec" else it }
            saver.launch(out)
        }) { Text(if (encrypt) "ابدأ التشفير" else "ابدأ فك التشفير") }
        if (job?.isActive == true) { Progress(done, size); OutlinedButton({ job?.cancel() }) { Text("إلغاء") } }
        if (status.isNotEmpty()) Note(status, Zcl.Ice)
        Note("التشفير: AES-256-GCM (بث مجزّأ عبر مكتبة Tink). اشتقاق المفتاح: PBKDF2-HMAC-SHA256 بـ 600 ألف تكرار مع Salt عشوائي. " +
            "المفتاح الخام يأتي من Z-KeySafe.")
        Note("تحذير: فقدان كلمة المرور أو المفتاح يعني عدم إمكانية استعادة البيانات. الحذف العادي للأصل لا يضمن محو كل النسخ.", Zcl.Amber)
    }
}

// ---------------- Z-KeySafe ----------------
@Composable
fun KeySafeScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val ks = remember { KeySafe(ctx) }
    var keys by remember { mutableStateOf(ks.list()) }
    var name by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var exportName by remember { mutableStateOf<String?>(null) }
    var exportPass by remember { mutableStateOf("") }
    var pendingBytes by remember { mutableStateOf<ByteArray?>(null) }
    var deleteName by remember { mutableStateOf<String?>(null) }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { dst ->
        val b = pendingBytes
        if (dst != null && b != null) {
            runCatching { ctx.contentResolver.openOutputStream(dst, "wt")!!.use { it.write(b) } }
                .onSuccess { msg = "تم تصدير المفتاح مشفراً بكلمة مرور." }
                .onFailure { msg = "فشل التصدير"; runCatching { DocumentsContract.deleteDocument(ctx.contentResolver, dst) } }
        }
        pendingBytes = null
    }
    ToolScreen("Z-KeySafe — إدارة المفاتيح", onBack) {
        OutlinedTextField(name, { name = it }, label = { Text("اسم المفتاح (حروف إنجليزية/أرقام/_/-)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Button(enabled = ks.validName(name), onClick = {
            msg = if (ks.create(name)) "تم إنشاء مفتاح AES-256 عشوائي." else "الاسم مستخدم أو غير صالح."
            keys = ks.list(); name = ""
        }) { Text("إنشاء مفتاح AES-256") }
        if (msg.isNotEmpty()) Note(msg, Zcl.Ice)
        if (keys.isEmpty()) Note("لا توجد مفاتيح بعد.")
        keys.forEach { k ->
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(k, color = Zcl.Ice, modifier = Modifier.weight(1f))
                OutlinedButton({ exportName = k }) { Text("تصدير") }
                OutlinedButton({ deleteName = k }) { Text("حذف") }
            }
        }
        Note("المفاتيح محمية بمفتاح Android Keystore غير قابل للتصدير ولا تعمل إلا على هذا الجهاز ما لم تصدّرها بنفسك.")
        Note("حذف مفتاح يجعل الملفات المشفرة به غير قابلة للاستعادة إلا إن كانت لديك نسخة مصدّرة.", Zcl.Amber)
    }
    exportName?.let { k ->
        AlertDialog(onDismissRequest = { exportName = null; exportPass = "" },
            title = { Text("تصدير المفتاح $k") },
            text = {
                Column {
                    Text("سيُصدَّر المفتاح مشفراً بكلمة مرور تختارها (8 أحرف فأكثر). من يملك الملف والكلمة يملك المفتاح.", fontSize = 13.sp)
                    OutlinedTextField(exportPass, { exportPass = it }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                }
            },
            confirmButton = {
                TextButton(enabled = exportPass.length >= 8, onClick = {
                    val raw = ks.get(k)
                    if (raw != null) {
                        pendingBytes = ZclCrypto.encryptBytes(raw, Secret.Password(exportPass.toCharArray()))
                        raw.fill(0)
                        saver.launch("$k.zclkey.zcle")
                    }
                    exportName = null; exportPass = ""
                }) { Text("تصدير") }
            },
            dismissButton = { TextButton({ exportName = null; exportPass = "" }) { Text("إلغاء") } })
    }
    deleteName?.let { k ->
        AlertDialog(onDismissRequest = { deleteName = null },
            title = { Text("حذف المفتاح $k؟") },
            text = { Text("لا يمكن التراجع. الملفات المشفرة بهذا المفتاح لن تُفك دون نسخة مصدّرة.") },
            confirmButton = { TextButton({ ks.delete(k); keys = ks.list(); deleteName = null }) { Text("حذف") } },
            dismissButton = { TextButton({ deleteName = null }) { Text("إلغاء") } })
    }
}

// ---------------- Z-Pass Audit ----------------
@Composable
fun PassScreen(onBack: () -> Unit) {
    val clip = LocalClipboardManager.current
    var pass by remember { mutableStateOf("") }
    var generated by remember { mutableStateOf("") }
    val r = PassAudit.evaluate(pass)
    ToolScreen("Z-Pass Audit — قوة كلمات المرور", onBack) {
        OutlinedTextField(pass, { pass = it }, label = { Text("اكتب كلمة المرور (تُفحص محلياً فقط)") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
        if (pass.isNotEmpty()) {
            LinearProgressIndicator(progress = { (r.score + 1) / 5f },
                color = when (r.score) { 0, 1 -> Zcl.Red; 2 -> Zcl.Amber; else -> Zcl.Green }, modifier = Modifier.fillMaxWidth())
            Text(r.label, color = Zcl.Ice, fontWeight = FontWeight.Bold)
            r.tips.forEach { Note("• $it") }
        }
        Button({ generated = PassAudit.generate(20) }) { Text("توليد كلمة مرور عشوائية") }
        if (generated.isNotEmpty()) {
            SelectionContainer { Text(generated, color = Zcl.Cyan) }
            OutlinedButton({ clip.setText(AnnotatedString(generated)) }) { Text("نسخ") }
        }
        Note("لا تُحفظ كلمات المرور ولا تُرسل ولا تُسجّل. التقييم تقديري ولا يضمن أن الكلمة لم تتسرب سابقاً.")
    }
}
