package com.zamhreer.zcl.analysis

import org.json.JSONTokener

/** Rule-based static analysis. Never executes the analyzed code. */
object CodeShield {
    const val RULES_VERSION = "ZCL-RULES-1.0.0"
    const val MAX_BYTES = 2 * 1024 * 1024
    val LIMITS = listOf(
        "تحليل ساكن بقواعد نمطية (Regex) سطراً بسطر؛ ليس محلل لغة كامل وقد يعطي إنذارات كاذبة أو يفوّته بعض الثغرات.",
        "لا يتتبع تدفق البيانات بين الملفات.",
        "لا يُشغَّل الكود ولا يُرسل إلى أي خدمة خارجية.",
        "الحد الأقصى للتحليل ${MAX_BYTES / 1024 / 1024} ميغابايت."
    )
    private val ALL = setOf("python", "php", "javascript", "html", "css", "json")
    private val JS = setOf("javascript", "html")

    private class Rule(val id: String, val name: String, val langs: Set<String>, val re: Regex, val sev: Severity,
                       val conf: String, val why: String, val fix: String, val secret: Boolean = false)

    private fun r(p: String) = Regex(p, RegexOption.IGNORE_CASE)
    private const val SUPER = "[$]_(GET|POST|REQUEST|COOKIE)"

    private val rules = listOf(
        Rule("PY001", "eval/exec", setOf("python"), Regex("""\b(eval|exec)\s*\("""), Severity.HIGH, "عالية",
            "تنفيذ نص كشيفرة قد يسمح بحقن أوامر.", "استبدله بـ ast.literal_eval أو منطق صريح."),
        Rule("PY002", "تنفيذ أوامر نظام", setOf("python"), Regex("""subprocess\.\w+\(.*shell\s*=\s*True|\bos\.(system|popen)\s*\("""), Severity.HIGH, "متوسطة",
            "تمرير مدخلات غير موثوقة لصدفة النظام يسمح بحقن الأوامر.", "استخدم subprocess بقائمة وسائط بدون shell=True."),
        Rule("PY003", "تعطيل التحقق من TLS", setOf("python"), Regex("""verify\s*=\s*False|_create_unverified_context|CERT_NONE"""), Severity.HIGH, "عالية",
            "يسمح بهجمات الوسيط.", "أبقِ التحقق مفعلاً وأصلح الشهادة بدل تعطيله."),
        Rule("PY004", "pickle على بيانات", setOf("python"), Regex("""\b(c?[Pp]ickle)\.loads?\("""), Severity.MEDIUM, "متوسطة",
            "فك pickle لبيانات غير موثوقة ينفذ كوداً.", "استخدم JSON."),
        Rule("PY005", "yaml.load بدون Loader آمن", setOf("python"), Regex("""yaml\.load\((?![^)]*Loader)"""), Severity.MEDIUM, "متوسطة",
            "قد ينشئ كائنات عشوائية.", "استخدم yaml.safe_load."),
        Rule("PY006", "مسار ملف من مدخل", setOf("python"), Regex("""\bopen\(\s*[^)]*(request\.|input\(|sys\.argv)"""), Severity.MEDIUM, "منخفضة",
            "قد يسمح بالوصول لمسارات خارج المقصود (Path Traversal).", "طبّع المسار وتحقق أنه داخل مجلد مسموح."),
        Rule("PY007", "خوارزمية تجزئة ضعيفة", setOf("python"), Regex("""hashlib\.(md5|sha1)\("""), Severity.LOW, "متوسطة",
            "MD5/SHA-1 غير مناسبة لكلمات المرور أو التوقيع.", "استخدم SHA-256 أو Argon2/bcrypt لكلمات المرور."),
        Rule("PHP001", "احتمال SQL Injection", setOf("php"), r("""(select|insert|update|delete)\b.*$SUPER"""), Severity.CRITICAL, "متوسطة",
            "دمج مدخل المستخدم في استعلام SQL.", "استخدم استعلامات مهيأة (PDO prepared statements)."),
        Rule("PHP002", "حقن أوامر نظام", setOf("php"), Regex("""\b(system|exec|shell_exec|passthru|popen|proc_open)\s*\(.*$SUPER"""), Severity.CRITICAL, "عالية",
            "مدخل المستخدم يصل لتنفيذ أمر.", "تجنب تنفيذ الأوامر أو استخدم escapeshellarg مع قائمة بيضاء."),
        Rule("PHP003", "eval", setOf("php"), Regex("""\beval\s*\("""), Severity.HIGH, "عالية",
            "تنفيذ كود ديناميكي.", "أزل eval."),
        Rule("PHP004", "إخراج غير مهرّب (XSS)", setOf("php"), r("""(echo|print)\b(?!.*(htmlspecialchars|htmlentities|intval)).*$SUPER"""), Severity.HIGH, "متوسطة",
            "طباعة مدخل المستخدم مباشرة.", "استخدم htmlspecialchars($" + "x, ENT_QUOTES, 'UTF-8')."),
        Rule("PHP005", "include/require بمدخل", setOf("php"), Regex("""\b(include|require)(_once)?\b.*$SUPER"""), Severity.CRITICAL, "عالية",
            "قد يسمح بتضمين ملفات عشوائية (LFI/RFI).", "استخدم قائمة بيضاء للملفات."),
        Rule("PHP006", "unserialize على مدخل", setOf("php"), Regex("""\bunserialize\s*\(.*$SUPER"""), Severity.HIGH, "عالية",
            "فك تسلسل بيانات غير موثوقة.", "استخدم json_decode."),
        Rule("PHP007", "setcookie بدون HttpOnly", setOf("php"), r("""\bsetcookie\s*\((?!.*httponly)"""), Severity.LOW, "منخفضة",
            "الكوكي قد يُقرأ عبر JavaScript.", "فعّل HttpOnly وSecure وSameSite."),
        Rule("JS001", "innerHTML/outerHTML", JS, Regex("""\.(innerHTML|outerHTML)\s*\+?="""), Severity.MEDIUM, "متوسطة",
            "إدراج HTML قد يسبب XSS إن حوى بيانات غير موثوقة.", "استخدم textContent أو نظّف المدخل."),
        Rule("JS002", "document.write", JS, Regex("""document\.write(ln)?\s*\("""), Severity.MEDIUM, "متوسطة",
            "كتابة HTML مباشرة وقد تسبب XSS.", "استخدم DOM APIs."),
        Rule("JS003", "eval/new Function", JS, Regex("""\beval\s*\(|new\s+Function\s*\("""), Severity.HIGH, "عالية",
            "تنفيذ نص كشيفرة.", "أزلها."),
        Rule("JS004", "DOM XSS: مصدر ← منفذ", JS, Regex("""(innerHTML|outerHTML|document\.write).*(location\.(hash|search|href)|document\.(URL|referrer)|window\.name)"""), Severity.HIGH, "عالية",
            "بيانات يتحكم بها المهاجم تصل لمنفذ يحقن HTML.", "نظّف المدخل أو استخدم textContent."),
        Rule("JS005", "سكربت خارجي عبر HTTP", setOf("html"), r("""<script[^>]+src\s*=\s*["']http://"""), Severity.HIGH, "عالية",
            "يمكن تعديله في الطريق.", "استخدم HTTPS مع Subresource Integrity."),
        Rule("JS006", "CSP ضعيف (unsafe-inline/eval)", JS, r("""Content-Security-Policy.*unsafe-(inline|eval)"""), Severity.MEDIUM, "متوسطة",
            "يُضعف حماية CSP من XSS.", "استخدم nonce/hash بدلاً منها."),
        Rule("JS007", "target=_blank بدون noopener", setOf("html"), r("""<a\b(?=[^>]*target\s*=\s*["']_blank["'])(?![^>]*noopener)"""), Severity.LOW, "منخفضة",
            "الصفحة المفتوحة قد تتحكم بالأصلية.", "أضف rel=\"noopener noreferrer\"."),
        Rule("CSS001", "CSS expression()", setOf("css", "html"), r("""expression\s*\("""), Severity.MEDIUM, "متوسطة",
            "ميزة قديمة تنفذ جافاسكربت.", "أزلها."),
        Rule("CSS002", "مورد CSS عبر HTTP", setOf("css", "html"), r("""url\(\s*["']?http://"""), Severity.LOW, "متوسطة",
            "مورد غير مشفّر.", "استخدم HTTPS."),
        Rule("SEC001", "سر/مفتاح مكتوب في المصدر", ALL, r("""(api[_-]?key|secret|passwd|password|token|private[_-]?key)["']?\s*[:=]\s*["'][^"'\s]{8,}["']"""),
            Severity.HIGH, "متوسطة", "الأسرار في المصدر قد تتسرب.", "انقلها لمتغيرات بيئة أو مخزن أسرار وبدّل القيمة المكشوفة.", true),
        Rule("SEC002", "مفتاح AWS", ALL, Regex("""AKIA[0-9A-Z]{16}"""), Severity.CRITICAL, "عالية", "نمط مفتاح وصول AWS.", "ألغِ المفتاح فوراً وأنشئ بديلاً.", true),
        Rule("SEC003", "مفتاح خاص", ALL, Regex("""-----BEGIN (RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"""), Severity.CRITICAL, "عالية", "مفتاح خاص داخل الملف.", "أزله وبدّل المفتاح.", true),
        Rule("SEC004", "رمز JWT", ALL, Regex("""eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"""), Severity.HIGH, "متوسطة", "رمز وصول قد يكون صالحاً.", "ألغِ الرمز.", true)
    )

    fun languageOf(name: String): String? = when (name.substringAfterLast('.', "").lowercase()) {
        "py" -> "python"; "php" -> "php"; "js", "mjs" -> "javascript"
        "html", "htm" -> "html"; "css" -> "css"; "json" -> "json"; else -> null
    }

    data class Result(val language: String, val lines: Int, val findings: List<Finding>)

    fun analyze(name: String, text: String): Result {
        val lang = languageOf(name) ?: return Result("غير مدعوم", 0, emptyList())
        val out = mutableListOf<Finding>()
        val lines = text.lines()
        val active = rules.filter { lang in it.langs }
        lines.forEachIndexed { i, line ->
            if (line.length > 5000) return@forEachIndexed
            val t = line.trim()
            val comment = (lang == "python" && t.startsWith("#")) ||
                ((lang == "javascript" || lang == "php") && (t.startsWith("//") || t.startsWith("*") || t.startsWith("/*"))) ||
                (lang == "php" && t.startsWith("#"))
            for (rule in active) {
                if (comment && !rule.secret) continue
                val m = rule.re.find(line) ?: continue
                val snippet = (if (rule.secret) line.replace(m.value, "***") else line).trim().take(140)
                out += Finding(rule.id, rule.name, rule.sev, rule.conf, snippet, rule.why, rule.fix, i + 1)
            }
        }
        if (lang == "json") {
            try {
                val tk = JSONTokener(text)
                tk.nextValue()
                if (tk.nextClean() != 0.toChar()) throw Exception("trailing")
            } catch (e: Exception) {
                out += Finding("JSON000", "بنية JSON غير صالحة", Severity.MEDIUM, "عالية", e.message?.take(100) ?: "",
                    "الملف لا يُفسَّر كـ JSON صحيح.", "أصلح الأقواس والفواصل.")
            }
        }
        if (lang == "css" && text.count { it == '{' } != text.count { it == '}' })
            out += Finding("CSS000", "أقواس CSS غير متوازنة", Severity.LOW, "عالية", "", "قد يعطل الأنماط.", "راجع الأقواس.")
        return Result(lang, lines.size, out.sortedWith(compareByDescending<Finding> { it.severity.weight }.thenBy { it.line }))
    }
}
