package com.zamhreer.zcl.ui

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zamhreer.zcl.analysis.*
import com.zamhreer.zcl.data.LocalLog
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream
import java.util.concurrent.CancellationException

private fun sevColor(s: Severity): Color = when (s) {
    Severity.CRITICAL, Severity.HIGH -> Zcl.Red
    Severity.MEDIUM -> Zcl.Amber
    Severity.LOW -> Zcl.Cyan
    Severity.INFO -> Zcl.Graphite
}

private fun verdictColor(v: String): Color = when {
    v.contains("خطر") -> Zcl.Red
    v.contains("مشبوه") || v.contains("مراجعة") -> Zcl.Amber
    v.contains("لم تُكتشف") || v.contains("اجتاز") -> Zcl.Green
    else -> Zcl.Graphite
}

@Composable
internal fun FindingCard(f: Finding) {
    Surface(shape = RoundedCornerShape(10.dp), color = Zcl.Navy, border = BorderStroke(1.dp, sevColor(f.severity).copy(alpha = .6f)),
        modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("[${f.severity.ar}] ${f.title}", color = sevColor(f.severity), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("${f.id} · ثقة: ${f.confidence}" + if (f.line > 0) " · السطر ${f.line}" else "", color = Zcl.Graphite, fontSize = 11.sp)
            if (f.evidence.isNotEmpty()) Text(f.evidence, color = Zcl.Ice, fontSize = 11.sp)
            Text(f.explanation, color = Zcl.Ice, fontSize = 12.sp)
            Text("التوصية: ${f.recommendation}", color = Zcl.Green, fontSize = 12.sp)
        }
    }
}

@Composable
internal fun VerdictBanner(text: String) {
    Surface(shape = RoundedCornerShape(10.dp), color = verdictColor(text).copy(alpha = .15f),
        border = BorderStroke(1.dp, verdictColor(text)), modifier = Modifier.fillMaxWidth()) {
        Text(text, color = verdictColor(text), fontWeight = FontWeight.Bold, modifier = Modifier.padding(10.dp))
    }
}

@Composable
internal fun rememberTextSaver(ctx: Context, getText: () -> String): (String) -> Unit {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { dst ->
        if (dst != null) runCatching { ctx.contentResolver.openOutputStream(dst, "wt")!!.use { it.write(getText().toByteArray()) } }
    }
    return { name -> launcher.launch(name) }
}

// ---------------- Z-Link Shield ----------------
@Composable
fun LinkScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val log = remember { LocalLog(ctx) }
    var input by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<LinkAnalyzer.Result>>(emptyList()) }
    var report by remember { mutableStateOf("") }
    val save = rememberTextSaver(ctx) { report }
    ToolScreen("Z-Link Shield — فحص الروابط", onBack) {
        OutlinedTextField(input, { input = it }, label = { Text("الصق رابطاً أو أكثر (كل رابط بسطر، حتى 20)") },
            modifier = Modifier.fillMaxWidth(), minLines = 3)
        Button(enabled = input.isNotBlank(), onClick = {
            results = input.lines().map { it.trim() }.filter { it.isNotEmpty() }.take(20).map { LinkAnalyzer.analyze(it) }
            log.recordCompleted()
        }) { Text("حلّل محلياً") }
        results.forEach { r ->
            Text(r.url.take(100), color = Zcl.Ice, fontSize = 12.sp)
            VerdictBanner(r.verdict)
            r.findings.forEach { FindingCard(it) }
        }
        if (results.isNotEmpty()) OutlinedButton({
            report = ZclReport.text("Z-Link Shield", LinkAnalyzer.RULES_VERSION, "Completed",
                results.map { ZclReport.Section(it.url, it.verdict, it.findings) }, LinkAnalyzer.LIMITS)
            save("zcl-link-report.txt")
        }) { Text("تصدير تقرير TXT") }
        Note("التحليل محلي بالكامل: التطبيق لا يتصل بالرابط ولا يفتحه ولا يقرأ الحافظة. الحكم مبني على مؤشرات وليس \"آمن 100%\".")
        LinkAnalyzer.LIMITS.forEach { Note("• $it") }
    }
}

// ---------------- Z-Code Shield ----------------
private fun readLimited(ins: java.io.InputStream, max: Int): ByteArray {
    val out = ByteArrayOutputStream()
    val buf = ByteArray(32 * 1024)
    var left = max
    while (left > 0) {
        val n = ins.read(buf, 0, minOf(buf.size, left))
        if (n < 0) break
        out.write(buf, 0, n); left -= n
    }
    return out.toByteArray()
}

@Composable
fun CodeScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val log = remember { LocalLog(ctx) }
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<CodeShield.Result?>(null) }
    var status by remember { mutableStateOf("") }
    var report by remember { mutableStateOf("") }
    val save = rememberTextSaver(ctx) { report }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            name = queryName(ctx, u); status = "جارٍ التحليل…"; result = null
            scope.launch {
                try {
                    val res = withContext(Dispatchers.IO) {
                        val bytes = ctx.contentResolver.openInputStream(u)!!.use { readLimited(it, CodeShield.MAX_BYTES) }
                        CodeShield.analyze(name, String(bytes, Charsets.UTF_8))
                    }
                    result = res
                    status = if (res.language == "غير مدعوم") "نوع الملف غير مدعوم (المدعوم: py, php, js, html, css, json)" else "اكتمل"
                    if (res.language != "غير مدعوم") log.recordCompleted()
                } catch (e: Exception) { status = "فشل التحليل: ${e.message}"; log.recordFailed() }
            }
        }
    }
    ToolScreen("Z-Code Shield — فحص الأكواد", onBack) {
        Button({ picker.launch(arrayOf("*/*")) }) { Text("اختيار ملف كود") }
        if (name.isNotEmpty()) Text(name, color = Zcl.Ice, fontSize = 13.sp)
        if (status.isNotEmpty()) Note(status, Zcl.Ice)
        result?.let { r ->
            if (r.language != "غير مدعوم") {
                Text("اللغة: ${r.language} · الأسطر: ${r.lines} · النتائج: ${r.findings.size}", color = Zcl.Cyan, fontSize = 13.sp)
                if (r.findings.isEmpty()) VerdictBanner("لم تُكتشف مؤشرات ضمن قواعد ${CodeShield.RULES_VERSION}")
                r.findings.take(150).forEach { FindingCard(it) }
                if (r.findings.size > 150) Note("عُرضت أول 150 نتيجة؛ التقرير يحوي الكل.")
                OutlinedButton({
                    report = ZclReport.text("Z-Code Shield", CodeShield.RULES_VERSION, "Completed",
                        listOf(ZclReport.Section(name, "${r.findings.size} نتيجة", r.findings)), CodeShield.LIMITS)
                    save("zcl-code-report.txt")
                }) { Text("تصدير تقرير TXT") }
            }
        }
        Note("لا يُشغَّل الكود ولا يُرسل لأي مكان. الأسرار تُخفى في المقتطفات المعروضة.")
        CodeShield.LIMITS.forEach { Note("• $it") }
    }
}

// ---------------- Z-File Guard ----------------
@Composable
fun FileGuardScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val log = remember { LocalLog(ctx) }
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var size by remember { mutableLongStateOf(0L) }
    var done by remember { mutableLongStateOf(0L) }
    var report by remember { mutableStateOf<FileGuard.Report?>(null) }
    var status by remember { mutableStateOf("") }
    var job by remember { mutableStateOf<Job?>(null) }
    var text by remember { mutableStateOf("") }
    val save = rememberTextSaver(ctx) { text }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            name = queryName(ctx, u); size = querySize(ctx, u); done = 0; report = null; status = "جارٍ الفحص…"
            job = scope.launch {
                try {
                    val res = withContext(Dispatchers.IO) {
                        FileGuard.analyze(name, { ctx.contentResolver.openInputStream(u)!! }, { done = it }, { !isActive })
                    }
                    report = res; status = "اكتمل"; log.recordCompleted()
                } catch (e: CancellationException) { status = "أُلغيت العملية"; log.recordFailed()
                } catch (e: Exception) { status = "فشل الفحص: ${e.message}"; log.recordFailed() }
            }
        }
    }
    ToolScreen("Z-File Guard — مؤشرات الملفات", onBack) {
        Button(enabled = job?.isActive != true, onClick = { picker.launch(arrayOf("*/*")) }) { Text("اختيار ملف للفحص") }
        if (name.isNotEmpty()) Text("$name (${fmtSize(size)})", color = Zcl.Ice, fontSize = 13.sp)
        if (job?.isActive == true) { Progress(done, size); OutlinedButton({ job?.cancel() }) { Text("إلغاء") } }
        if (status.isNotEmpty()) Note(status, Zcl.Ice)
        report?.let { r ->
            VerdictBanner(r.verdict)
            Text("النوع الفعلي: ${r.type}", color = Zcl.Cyan, fontSize = 13.sp)
            SelectionContainer {
                Column { Text("SHA-256: ${r.sha256}", color = Zcl.Graphite, fontSize = 10.sp); Text("SHA-512: ${r.sha512}", color = Zcl.Graphite, fontSize = 10.sp) }
            }
            r.findings.forEach { FindingCard(it) }
            OutlinedButton({
                text = ZclReport.text("Z-File Guard", FileGuard.RULES_VERSION, "Completed",
                    listOf(ZclReport.Section("${r.name} (${r.size} bytes) SHA-256:${r.sha256}", r.verdict, r.findings)), FileGuard.LIMITS)
                save("zcl-file-report.txt")
            }) { Text("تصدير تقرير TXT") }
        }
        Note("لا يُنفَّذ الملف أبداً. هذا فحص مؤشرات وليس مضاد فيروسات.", Zcl.Amber)
        FileGuard.LIMITS.forEach { Note("• $it") }
    }
}

// ---------------- Z-Privacy Check ----------------
@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    data class Item(val title: String, val value: String, val color: Color)
    val items = remember {
        val l = mutableListOf<Item>()
        val perms = runCatching {
            @Suppress("DEPRECATION")
            ctx.packageManager.getPackageInfo(ctx.packageName, PackageManager.GET_PERMISSIONS).requestedPermissions
        }.getOrNull()
        l += Item("أذونات هذا التطبيق", if (perms.isNullOrEmpty()) "لا يطلب أي إذن (يستخدم منتقي الملفات الرسمي)" else perms.joinToString("\n"), Zcl.Green)
        val secure = (ctx.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager)?.isDeviceSecure
        l += Item("قفل الشاشة", when (secure) { true -> "مفعّل"; false -> "غير مفعّل — فعّل PIN أو بصمة"; else -> "تعذر التحديد" },
            if (secure == true) Zcl.Green else Zcl.Amber)
        val backup = (ctx.applicationInfo.flags and ApplicationInfo.FLAG_ALLOW_BACKUP) != 0
        l += Item("النسخ الاحتياطي لبيانات هذا التطبيق", if (backup) "مسموح" else "غير مسموح (ملفات ومفاتيح ZCL لا تدخل نسخ النظام)", if (backup) Zcl.Amber else Zcl.Green)
        val patch = Build.VERSION.SECURITY_PATCH
        val months = runCatching {
            java.time.temporal.ChronoUnit.MONTHS.between(java.time.LocalDate.parse(patch), java.time.LocalDate.now())
        }.getOrNull()
        l += Item("تحديث الأمان", "Android ${Build.VERSION.RELEASE} · $patch" + (months?.let { " (قبل $it شهراً)" } ?: ""),
            if (months != null && months > 12) Zcl.Amber else Zcl.Green)
        val adb = runCatching { Settings.Global.getInt(ctx.contentResolver, Settings.Global.ADB_ENABLED, 0) }.getOrDefault(0)
        l += Item("تصحيح USB (ADB)", if (adb == 1) "مفعّل — عطّله إن لم تحتجه" else "معطّل", if (adb == 1) Zcl.Amber else Zcl.Green)
        l
    }
    fun open(a: String, uri: Uri? = null) = runCatching {
        ctx.startActivity(Intent(a).apply { if (uri != null) data = uri; addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
    }
    ToolScreen("Z-Privacy Check — مراجعة الخصوصية", onBack) {
        items.forEach { it ->
            Surface(shape = RoundedCornerShape(10.dp), color = Zcl.Navy, border = BorderStroke(1.dp, it.color.copy(alpha = .6f)), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Text(it.title, color = it.color, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(it.value, color = Zcl.Ice, fontSize = 12.sp)
                }
            }
        }
        Button({ open(Settings.ACTION_SECURITY_SETTINGS) }) { Text("فتح إعدادات الأمان") }
        OutlinedButton({ open(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")) }) { Text("إعدادات هذا التطبيق") }
        Note("لمراجعة أذونات بقية التطبيقات: الإعدادات ← الخصوصية ← مدير الأذونات، وراجع الكاميرا والمايكروفون والموقع.")
        Note("الحدود: التطبيق يعرض فقط ما يسمح به أندرويد؛ لا يفحص التطبيقات الأخرى ولا يصل لبياناتها المحمية، ولا يدّعي فحص الهاتف كاملاً.", Zcl.Amber)
    }
}
