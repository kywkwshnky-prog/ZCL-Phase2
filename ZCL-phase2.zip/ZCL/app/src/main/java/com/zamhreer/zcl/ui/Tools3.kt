package com.zamhreer.zcl.ui

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zamhreer.zcl.analysis.*
import com.zamhreer.zcl.data.LocalLog
import kotlinx.coroutines.*
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.CancellationException

@Composable
private fun AuthCheck(checked: Boolean, onChange: (Boolean) -> Unit, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked, onChange)
        Text(text, color = Zcl.Ice, fontSize = 12.sp, modifier = Modifier.weight(1f))
    }
}

// ---------------- Z-Scan ----------------
@Composable
fun ScanScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val log = remember { LocalLog(ctx) }
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf("") }
    var authorized by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<ZScan.Result?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }
    var report by remember { mutableStateOf("") }
    val save = rememberTextSaver(ctx) { report }
    ToolScreen("Z-Scan — فحص إعدادات المواقع", onBack) {
        OutlinedTextField(url, { url = it }, label = { Text("عنوان الموقع (مثال: example.com)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        AuthCheck(authorized, { authorized = it }, "أؤكد أنني أملك هذا الموقع أو لدي تصريح صريح بفحصه.")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = authorized && url.isNotBlank() && job?.isActive != true, onClick = {
                result = null
                job = scope.launch {
                    try {
                        val r = withContext(Dispatchers.IO) { ZScan.scan(url, { !isActive }) }
                        result = r
                        if (r.status == "اكتمل") log.recordCompleted() else log.recordFailed()
                    } catch (e: CancellationException) { log.recordFailed() }
                }
            }) { Text("ابدأ الفحص") }
            if (job?.isActive == true) OutlinedButton({ job?.cancel() }) { Text("إلغاء") }
        }
        if (job?.isActive == true) LinearProgressIndicator(color = Zcl.Cyan, modifier = Modifier.fillMaxWidth())
        result?.let { r ->
            Note("الحالة: ${r.status}", Zcl.Ice)
            VerdictBanner(r.verdict)
            if (r.httpCode > 0) Text("HTTP ${r.httpCode} · زمن الاستجابة ${r.latencyMs} ms", color = Zcl.Cyan, fontSize = 12.sp)
            if (r.finalUrl.isNotEmpty()) Note("الوجهة النهائية: ${r.finalUrl}")
            r.chain.takeIf { it.size > 1 }?.let { Note("التحويلات: " + it.joinToString(" ← ")) }
            r.tlsInfo.forEach { Note(it, Zcl.Ice) }
            r.findings.forEach { FindingCard(it) }
            OutlinedButton({
                report = ZclReport.text("Z-Scan", ZScan.RULES_VERSION, r.status,
                    listOf(ZclReport.Section("${r.target} → ${r.finalUrl}", r.verdict, r.findings)), ZScan.LIMITS)
                save("zcl-scan-report.txt")
            }) { Text("تصدير تقرير TXT") }
        }
        Note("الفحص يتحقق من الشهادة دون تعطيل TLS، ويرفض أي هدف يشير لعنوان داخلي (SSRF)، ولا ينفذ استغلالاً ولا تخميناً.", Zcl.Amber)
        ZScan.LIMITS.forEach { Note("• $it") }
    }
}

// ---------------- Z-Net ----------------
private fun netInfo(ctx: Context): List<Pair<String, String>> {
    val out = mutableListOf<Pair<String, String>>()
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    if (cm == null) { out += "الاتصال" to "تعذر الوصول لخدمة الشبكة"; return out }
    val net = cm.activeNetwork
    val caps = net?.let { cm.getNetworkCapabilities(it) }
    if (net == null || caps == null) { out += "الاتصال" to "لا توجد شبكة نشطة"; return out }
    val type = when {
        caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "بيانات الجوال"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
        else -> "غير معروف"
    }
    out += "نوع الاتصال" to type
    out += "الإنترنت" to if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) "متصل ومتحقق منه" else "غير متحقق (قد لا يوجد إنترنت)"
    val lp = cm.getLinkProperties(net)
    if (lp != null) {
        out += "عناوين الجهاز" to (lp.linkAddresses.map { it.address.hostAddress ?: "" }.filter { it.isNotEmpty() }.joinToString("\n").ifEmpty { "غير متاح" })
        out += "البوابة الافتراضية" to (lp.routes.firstOrNull { it.isDefaultRoute && it.gateway != null }?.gateway?.hostAddress ?: "غير متاح")
        out += "خوادم DNS" to (lp.dnsServers.mapNotNull { it.hostAddress }.joinToString("\n").ifEmpty { "غير متاح" })
        if (Build.VERSION.SDK_INT >= 28) {
            out += "Private DNS (DoT)" to if (lp.isPrivateDnsActive) "مفعّل ${lp.privateDnsServerName ?: ""}" else "غير مفعّل"
        }
    }
    return out
}

private fun suggestLan(ctx: Context): String? {
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return null
    val net = cm.activeNetwork ?: return null
    val ip = cm.getLinkProperties(net)?.linkAddresses?.map { it.address }?.firstOrNull { it is Inet4Address && it.isSiteLocalAddress } ?: return null
    val p = ip.hostAddress?.split('.') ?: return null
    return if (p.size == 4) "${p[0]}.${p[1]}.${p[2]}.0/24" else null
}

private val ROUTER_TIPS = listOf(
    "غيّر كلمة مرور لوحة الراوتر الافتراضية (admin).",
    "استخدم WPA3 أو WPA2-AES وكلمة مرور Wi-Fi طويلة (16 حرفاً فأكثر).",
    "عطّل WPS وعطّل الإدارة عن بُعد (Remote Management) ما لم تحتجها.",
    "حدّث فيرموير الراوتر بانتظام.",
    "فعّل شبكة ضيوف للأجهزة غير الموثوقة وأجهزة IoT.",
    "راجع قائمة الأجهزة المتصلة من لوحة الراوتر واحذف المجهول.",
    "عطّل UPnP إن لم تحتجه، وأغلق أي منافذ مفتوحة للإنترنت دون حاجة.",
    "استخدم DNS موثوقاً أو Private DNS على الهاتف."
)

@Composable
fun NetScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val log = remember { LocalLog(ctx) }
    val scope = rememberCoroutineScope()
    var info by remember { mutableStateOf(netInfo(ctx)) }
    var latency by remember { mutableStateOf<List<String>>(emptyList()) }
    var testing by remember { mutableStateOf(false) }
    var target by remember { mutableStateOf("") }
    var portsText by remember { mutableStateOf("22,23,80,443,445,3389,5555,8080") }
    var authorized by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var done by remember { mutableIntStateOf(0) }
    var total by remember { mutableIntStateOf(0) }
    var job by remember { mutableStateOf<Job?>(null) }
    var findings by remember { mutableStateOf<List<Finding>?>(null) }
    var scanned by remember { mutableStateOf("") }
    var report by remember { mutableStateOf("") }
    val save = rememberTextSaver(ctx) { report }

    ToolScreen("Z-Net — تحليل الشبكات", onBack) {
        Text("حالة الشبكة", color = Zcl.Cyan, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        info.forEach { (k, v) ->
            Column { Text(k, color = Zcl.Graphite, fontSize = 11.sp); Text(v, color = Zcl.Ice, fontSize = 13.sp) }
        }
        OutlinedButton({ info = netInfo(ctx) }) { Text("تحديث") }
        Note("تفاصيل Wi-Fi (اسم الشبكة/BSSID) تتطلب إذن الموقع في أندرويد، ولذلك لا يطلبها التطبيق ولا يعرضها.")

        HorizontalDivider(color = Zcl.Cyan.copy(alpha = .3f))
        Text("قياس زمن الاتصال (اختياري)", color = Zcl.Cyan, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        Note("سيتصل التطبيق بالمنفذ 443 على 1.1.1.1 (Cloudflare) و8.8.8.8 (Google) ويحل اسم example.com عبر DNS جهازك. لا تُرسل أي بيانات شخصية.")
        Button(enabled = !testing, onClick = {
            testing = true; latency = emptyList()
            scope.launch {
                latency = withContext(Dispatchers.IO) {
                    val l = mutableListOf<String>()
                    for (h in listOf("1.1.1.1", "8.8.8.8")) {
                        val t0 = System.nanoTime()
                        val ok = try { Socket().use { it.connect(InetSocketAddress(h, 443), 3000) }; true } catch (e: Exception) { false }
                        l += if (ok) "$h:443 ← ${(System.nanoTime() - t0) / 1_000_000} ms" else "$h:443 ← تعذر الاتصال"
                    }
                    val t1 = System.nanoTime()
                    val ok = try { InetAddress.getByName("example.com"); true } catch (e: Exception) { false }
                    l += "DNS (example.com) ← " + if (ok) "${(System.nanoTime() - t1) / 1_000_000} ms" else "تعذر"
                    l
                }
                testing = false; log.recordCompleted()
            }
        }) { Text("ابدأ القياس") }
        latency.forEach { Text(it, color = Zcl.Ice, fontSize = 12.sp) }

        HorizontalDivider(color = Zcl.Cyan.copy(alpha = .3f))
        Text("فحص شبكة محلية تملكها", color = Zcl.Cyan, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        OutlinedTextField(target, { target = it }, label = { Text("عنوان أو نطاق (مثال: 192.168.1.0/24)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedButton({ suggestLan(ctx)?.let { target = it } ?: run { msg = "تعذر اقتراح نطاق (لا Wi-Fi خاص نشط)" } }) { Text("اقتراح من شبكتي الحالية") }
        OutlinedTextField(portsText, { portsText = it }, label = { Text("المنافذ (حتى ${LanScan.MAX_PORTS})") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        AuthCheck(authorized, { authorized = it }, "أؤكد أن هذه الشبكة ملكي أو لدي تصريح بفحصها.")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = authorized && target.isNotBlank() && job?.isActive != true, onClick = {
                val (hosts, err) = NetGuard.parseLanTarget(target)
                val (ports, perr) = LanScan.parsePorts(portsText)
                if (hosts == null) { msg = err; return@Button }
                if (ports == null) { msg = perr; return@Button }
                msg = ""; findings = null; done = 0; total = hosts.size * ports.size; scanned = target.trim()
                job = scope.launch {
                    try {
                        val res = LanScan.scan(hosts, ports) { d, t -> done = d; total = t }
                        findings = LanScan.toFindings(res); log.recordCompleted()
                        msg = "اكتمل: فُحصت ${hosts.size} عنواناً × ${ports.size} منفذاً."
                    } catch (e: CancellationException) { msg = "أُلغيت العملية"; log.recordFailed() }
                }
            }) { Text("ابدأ الفحص") }
            if (job?.isActive == true) OutlinedButton({ job?.cancel() }) { Text("إلغاء") }
        }
        if (job?.isActive == true) { LinearProgressIndicator(progress = { if (total > 0) done / total.toFloat() else 0f }, color = Zcl.Cyan, modifier = Modifier.fillMaxWidth()); Note("$done / $total") }
        if (msg.isNotEmpty()) Note(msg, Zcl.Ice)
        findings?.let { fs ->
            if (fs.isEmpty()) VerdictBanner("لم تُكتشف منافذ مفتوحة ضمن المنافذ المحددة")
            fs.forEach { FindingCard(it) }
            OutlinedButton({
                report = ZclReport.text("Z-Net (LAN)", "ZCL-NET-1.0.0", "Completed",
                    listOf(ZclReport.Section(scanned, "${fs.size} منفذ مفتوح", fs)), LanScan.LIMITS)
                save("zcl-net-report.txt")
            }) { Text("تصدير تقرير TXT") }
        }
        LanScan.LIMITS.forEach { Note("• $it") }

        HorizontalDivider(color = Zcl.Cyan.copy(alpha = .3f))
        Text("قائمة تأمين الراوتر والشبكة المنزلية", color = Zcl.Cyan, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        ROUTER_TIPS.forEach { Note("✓ $it", Zcl.Ice) }
    }
}
