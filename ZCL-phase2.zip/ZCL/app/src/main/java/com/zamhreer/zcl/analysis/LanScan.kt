package com.zamhreer.zcl.analysis

import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicInteger

/** Bounded TCP-connect check for networks the user owns. Private ranges only, hard caps everywhere. */
object LanScan {
    const val MAX_PORTS = 10
    const val MAX_HOSTS = 256
    const val TIMEOUT_MS = 400
    private const val CONCURRENCY = 32
    val LIMITS = listOf(
        "فحص اتصال TCP بسيط لمنافذ يحددها المستخدم (حتى $MAX_PORTS) على عناوين خاصة فقط وبنطاق أقصاه /24.",
        "مهلة $TIMEOUT_MS ملي ثانية لكل محاولة و$CONCURRENCY اتصالاً متزامناً كحد أقصى.",
        "قد يمنع أندرويد أو الراوتر بعض الاتصالات؛ لا يدّعي الفاحص رؤية كل الأجهزة.",
        "لا تعطيل شبكات ولا قطع أجهزة ولا التقاط كلمات مرور ولا هجمات إغراق."
    )
    val SERVICES = mapOf(21 to "FTP", 22 to "SSH", 23 to "Telnet", 25 to "SMTP", 53 to "DNS", 80 to "HTTP", 110 to "POP3",
        139 to "NetBIOS", 143 to "IMAP", 443 to "HTTPS", 445 to "SMB", 3389 to "RDP", 5555 to "ADB", 8080 to "HTTP-alt", 8443 to "HTTPS-alt")

    data class HostResult(val host: String, val open: List<Int>)

    fun parsePorts(text: String): Pair<List<Int>?, String> {
        val ports = text.split(',', '،', ' ').map { it.trim() }.filter { it.isNotEmpty() }.map { it.toIntOrNull() ?: return null to "منفذ غير صالح: $it" }
        if (ports.isEmpty()) return null to "أدخل منفذاً واحداً على الأقل."
        if (ports.size > MAX_PORTS) return null to "الحد الأقصى $MAX_PORTS منافذ."
        if (ports.any { it !in 1..65535 }) return null to "المنافذ بين 1 و65535."
        return ports.distinct() to ""
    }

    private fun connect(host: String, port: Int): Boolean = try {
        Socket().use { it.connect(InetSocketAddress(host, port), TIMEOUT_MS) }; true
    } catch (e: IOException) { false }

    suspend fun scan(hosts: List<String>, ports: List<Int>, progress: (Int, Int) -> Unit): List<HostResult> = coroutineScope {
        require(hosts.size <= MAX_HOSTS && ports.size <= MAX_PORTS)
        val sem = Semaphore(CONCURRENCY)
        val done = AtomicInteger(0)
        val total = hosts.size * ports.size
        hosts.map { h ->
            async(Dispatchers.IO) {
                val open = mutableListOf<Int>()
                for (p in ports) {
                    ensureActive()
                    sem.withPermit { if (connect(h, p)) open += p }
                    progress(done.incrementAndGet(), total)
                }
                HostResult(h, open)
            }
        }.awaitAll().filter { it.open.isNotEmpty() }
    }

    fun toFindings(results: List<HostResult>): List<Finding> = results.flatMap { r ->
        r.open.map { p ->
            val name = SERVICES[p] ?: "غير معروف"
            val (sev, why, fix) = when (p) {
                23 -> Triple(Severity.HIGH, "Telnet غير مشفّر وكلمات المرور تمر بوضوح.", "عطّله واستخدم SSH.")
                5555 -> Triple(Severity.HIGH, "ADB عبر الشبكة يسمح بالتحكم بالجهاز.", "عطّل التصحيح اللاسلكي.")
                21, 139, 445, 3389 -> Triple(Severity.MEDIUM, "خدمة مشاركة/وصول عن بعد كثيرة الاستهداف.", "أغلقها أو قيّدها وفعّل كلمات مرور قوية.")
                80, 8080 -> Triple(Severity.LOW, "واجهة ويب بلا تشفير.", "فعّل HTTPS إن أمكن.")
                else -> Triple(Severity.INFO, "منفذ مفتوح.", "تأكد أنه مقصود.")
            }
            Finding("NET-PORT-$p", "منفذ $p مفتوح ($name)", sev, "عالية", "${r.host}:$p", why, fix)
        }
    }.sortedByDescending { it.severity.weight }
}
