package com.zamhreer.zcl.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zamhreer.zcl.R
import com.zamhreer.zcl.data.*
import kotlinx.coroutines.delay

const val TELEGRAM_URL = "https://t.me/rtf60"
const val APP_VERSION = "2.0.0-phase2"

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val steps = listOf("تهيئة واجهة المستخدم", "تحميل الإعدادات المحلية", "التحقق من جاهزية الوحدات")
    var index by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        // Each step is shown only after its (lightweight) init has actually run.
        steps.indices.forEach { i -> index = i; delay(450) }
        onDone()
    }
    Column(Modifier.fillMaxSize().background(Zcl.Void), Arrangement.Center, Alignment.CenterHorizontally) {
        Image(painterResource(R.drawable.zcl_banner), null, Modifier.fillMaxWidth(0.8f).weight(1f), contentScale = ContentScale.Fit)
        Text(steps[index], color = Zcl.Cyan, fontSize = 14.sp)
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(progress = { (index + 1) / steps.size.toFloat() }, color = Zcl.Cyan, modifier = Modifier.fillMaxWidth(0.6f))
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
fun DashboardScreen(onOpen: (String) -> Unit, onAbout: () -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val log = remember { LocalLog(ctx) }
    var selected by remember { mutableStateOf<Engine?>(null) }
    Column(Modifier.fillMaxSize().background(Zcl.Void).statusBarsPadding().padding(16.dp)) {
        Text("ZAMHREER CYBER LAB", color = Zcl.Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Text("مختبر زمهرير للأمن السيبراني", color = Zcl.Ice, fontSize = 14.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
            Stat("عمليات مكتملة", log.completed.toString(), Modifier.weight(1f))
            Stat("فاشلة / ملغاة", log.failed.toString(), Modifier.weight(1f))
        }
        Text(if (log.completed + log.failed == 0) "لا توجد عمليات بعد" else "", color = Zcl.Graphite, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
        LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(ENGINES) { e -> EngineTile(e) { if (e.status == EngineStatus.READY) onOpen(e.id) else selected = e } }
            item { SimpleTile("الإعدادات", androidx.compose.material.icons.Icons.Filled.Settings, onSettings) }
            item { SimpleTile("حول التطبيق", androidx.compose.material.icons.Icons.Filled.Info, onAbout) }
        }
        Footer()
    }
    selected?.let { e ->
        AlertDialog(
            onDismissRequest = { selected = null },
            confirmButton = { TextButton({ selected = null }) { Text("حسناً") } },
            title = { Text("${e.code} — ${e.title}") },
            text = { Text("هذه الوحدة لم تُنجز بعد، وهي مجدولة للمرحلة ${e.phase}. لن تظهر كجاهزة حتى يكتمل محركها الحقيقي.") }
        )
    }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier) {
    Surface(modifier, shape = RoundedCornerShape(12.dp), color = Zcl.Navy, border = BorderStroke(1.dp, Zcl.Cyan.copy(alpha = .35f))) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = Zcl.Cyan, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Zcl.Graphite, fontSize = 12.sp)
        }
    }
}

@Composable
private fun EngineTile(e: Engine, onClick: () -> Unit) {
    Surface(Modifier.clickable(onClick = onClick).alpha(if (e.status == EngineStatus.READY) 1f else .7f),
        shape = RoundedCornerShape(14.dp), color = Zcl.Navy, border = BorderStroke(1.dp, Zcl.Cyan.copy(alpha = .5f))) {
        Column(Modifier.padding(10.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(e.icon, null, tint = Zcl.Cyan, modifier = Modifier.size(32.dp))
            Spacer(Modifier.height(6.dp))
            Text(e.title, color = Zcl.Ice, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 1)
            Text(e.status.label, color = if (e.status == EngineStatus.READY) Zcl.Green else Zcl.Amber, fontSize = 10.sp)
        }
    }
}

@Composable
private fun SimpleTile(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Surface(Modifier.clickable(onClick = onClick), shape = RoundedCornerShape(14.dp), color = Zcl.Navy, border = BorderStroke(1.dp, Zcl.Cyan.copy(alpha = .5f))) {
        Column(Modifier.padding(10.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Zcl.Cyan, modifier = Modifier.size(32.dp))
            Spacer(Modifier.height(6.dp))
            Text(title, color = Zcl.Ice, fontSize = 12.sp, maxLines = 1)
            Text(" ", fontSize = 10.sp)
        }
    }
}

@Composable
fun Footer() {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp).navigationBarsPadding(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("تطوير وبرمجة: حسن نصرت حربي", color = Zcl.Ice, fontSize = 12.sp)
        Text("© جميع الحقوق محفوظة للمبرمج حسن نصرت حربي", color = Zcl.Graphite, fontSize = 10.sp)
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().background(Zcl.Void).statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Image(painterResource(R.mipmap.ic_launcher), null, Modifier.size(120.dp))
        Text("ZAMHREER CYBER LAB", color = Zcl.Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("الإصدار $APP_VERSION", color = Zcl.Graphite, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
        Text("تطوير وبرمجة: حسن نصرت حربي", color = Zcl.Ice)
        Text("© جميع الحقوق محفوظة للمبرمج حسن نصرت حربي", color = Zcl.Ice, fontSize = 13.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        Button({ ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(TELEGRAM_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
            Text("تواصل مع المبرمج عبر Telegram")
        }
        Spacer(Modifier.height(8.dp))
        Text("إن لم يفتح تطبيق Telegram سيُفتح الرابط في المتصفح.", color = Zcl.Graphite, fontSize = 11.sp)
        Spacer(Modifier.height(16.dp))
        Text("حالة النسخة: المرحلة الثانية. الجاهز: Z-Hash وZ-Encrypt وZ-KeySafe وZ-Pass Audit. بقية المحركات قيد التطوير ولا تُعرض كجاهزة قبل اكتمالها.", color = Zcl.Amber, fontSize = 12.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onBack) { Text("رجوع") }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val log = remember { LocalLog(ctx) }
    var confirmClear by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(Zcl.Void).statusBarsPadding().padding(20.dp)) {
        Text("الإعدادات", color = Zcl.Cyan, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text("الخصوصية: كل البيانات محلية ولا يُرسل شيء إلى أي خادم. التطبيق لا يطلب أي صلاحيات.", color = Zcl.Ice, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        Button({ confirmClear = true }) { Text("مسح السجل المحلي") }
        Spacer(Modifier.weight(1f))
        OutlinedButton(onBack) { Text("رجوع") }
    }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        confirmButton = { TextButton({ log.clear(); confirmClear = false }) { Text("مسح") } },
        dismissButton = { TextButton({ confirmClear = false }) { Text("إلغاء") } },
        title = { Text("مسح السجل؟") },
        text = { Text("سيُحذف سجل العدادات المحلي فقط، ولن تُحذف أي ملفات.") }
    )
}
