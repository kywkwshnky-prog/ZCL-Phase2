package com.zamhreer.zcl.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zamhreer.zcl.R
import com.zamhreer.zcl.data.*
import kotlinx.coroutines.delay

const val TELEGRAM_URL = "https://t.me/rtf60"
const val APP_VERSION = "2.0.0-phase4"

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val steps = listOf("تهيئة واجهة المستخدم", "تحميل الإعدادات المحلية", "التحقق من جاهزية الوحدات")
    var index by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        steps.indices.forEach { i -> index = i; delay(450) }
        onDone()
    }
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        Image(painterResource(R.drawable.zcl_banner), null, Modifier.fillMaxWidth(0.85f).weight(1f), contentScale = ContentScale.Fit)
        Text(steps[index], color = Zcl.Cyan, fontSize = 14.sp)
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(progress = { (index + 1) / steps.size.toFloat() }, color = Zcl.Cyan, modifier = Modifier.fillMaxWidth(0.6f))
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
fun DashboardScreen(onOpen: (String) -> Unit, onAbout: () -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val log = remember { LocalLog(ctx) }
    var selected by remember { mutableStateOf<Engine?>(null) }
    val ready = ENGINES.count { it.status == EngineStatus.READY }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 14.dp)) {
        LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(painterResource(R.mipmap.ic_launcher), null, Modifier.size(104.dp).clip(RoundedCornerShape(24.dp))
                        .border(1.5.dp, Brush.linearGradient(listOf(Zcl.Cyan, Color.Transparent, Zcl.Cyan)), RoundedCornerShape(24.dp)))
                    Spacer(Modifier.height(8.dp))
                    Text("ZAMHREER", color = Zcl.Ice, fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 6.sp)
                    Text("CYBER LAB", color = Zcl.Cyan, fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 10.sp)
                    Text("مختبر زمهرير للأمن السيبراني", color = Zcl.Graphite, fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    Text("أمان  ·  تحليل  ·  حماية", color = Zcl.Cyan.copy(alpha = .8f), fontSize = 12.sp, letterSpacing = 2.sp)
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), Arrangement.spacedBy(8.dp)) {
                    Stat("محركات جاهزة", "$ready/${ENGINES.size}", Zcl.Green, Modifier.weight(1f))
                    Stat("عمليات مكتملة", log.completed.toString(), Zcl.Cyan, Modifier.weight(1f))
                    Stat("فاشلة / ملغاة", log.failed.toString(), if (log.failed > 0) Zcl.Amber else Zcl.Graphite, Modifier.weight(1f))
                }
            }
            items(ENGINES) { e ->
                HexTile(e.title, e.code, e.icon, if (e.status == EngineStatus.READY) Zcl.Cyan else Zcl.Graphite,
                    if (e.status == EngineStatus.READY) "جاهز" else "قيد التطوير",
                    if (e.status == EngineStatus.READY) Zcl.Green else Zcl.Amber) {
                    if (e.status == EngineStatus.READY) onOpen(e.id) else selected = e
                }
            }
            item { HexTile("الإعدادات", "Settings", Icons.Filled.Settings, Zcl.Cyan, "", Zcl.Green, onSettings) }
            item { HexTile("حول التطبيق", "About", Icons.Filled.Info, Zcl.Cyan, "", Zcl.Green, onAbout) }
        }
        Footer()
    }
    selected?.let { e ->
        AlertDialog(
            onDismissRequest = { selected = null },
            confirmButton = { TextButton({ selected = null }) { Text("حسناً") } },
            title = { Text("${e.code} — ${e.title}") },
            text = { Text("هذه الوحدة لم تُنجز بعد ولن تظهر كجاهزة حتى يكتمل محركها الحقيقي.") }
        )
    }
}

@Composable
private fun Stat(label: String, value: String, accent: Color, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(12.dp)).background(Zcl.Navy.copy(alpha = .75f))
        .border(1.dp, accent.copy(alpha = .45f), RoundedCornerShape(12.dp)).padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = accent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Zcl.Graphite, fontSize = 10.sp)
    }
}

@Composable
private fun HexTile(title: String, code: String, icon: ImageVector, accent: Color, status: String, statusColor: Color, onClick: () -> Unit) {
    Box(Modifier.aspectRatio(0.92f).clip(HexShape)
        .background(Brush.verticalGradient(listOf(Color(0xFF0C2640), Color(0xFF061423))))
        .border(1.2.dp, Brush.linearGradient(listOf(accent, accent.copy(alpha = .15f), accent)), HexShape)
        .clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(6.dp)) {
            Icon(icon, null, tint = accent, modifier = Modifier.size(30.dp))
            Spacer(Modifier.height(4.dp))
            Text(title, color = Zcl.Ice, fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 1, fontWeight = FontWeight.SemiBold)
            Text(code, color = Zcl.Graphite, fontSize = 8.sp, maxLines = 1)
            if (status.isNotEmpty()) Text(status, color = statusColor, fontSize = 9.sp)
        }
    }
}

@Composable
fun Footer() {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp).navigationBarsPadding(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("تطوير وبرمجة: حسن نصرت حربي", color = Zcl.Ice, fontSize = 12.sp)
        Text("© جميع الحقوق محفوظة للمبرمج حسن نصرت حربي", color = Zcl.Graphite, fontSize = 10.sp)
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Image(painterResource(R.mipmap.ic_launcher), null, Modifier.size(120.dp).clip(RoundedCornerShape(28.dp)))
        Text("ZAMHREER CYBER LAB", color = Zcl.Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("الإصدار $APP_VERSION", color = Zcl.Graphite, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
        Text("تطوير وبرمجة: حسن نصرت حربي", color = Zcl.Ice)
        Text("© جميع الحقوق محفوظة للمبرمج حسن نصرت حربي", color = Zcl.Ice, fontSize = 13.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        Button({ ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(TELEGRAM_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
            Text("تواصل مع المبرمج عبر Telegram")
        }
        Spacer(Modifier.height(8.dp))
        Text("إن لم يفتح تطبيق Telegram سيُفتح الرابط في المتصفح.", color = Zcl.Graphite, fontSize = 11.sp)
        Spacer(Modifier.height(16.dp))
        Text("الجاهز: Z-Hash · Z-Encrypt · Z-KeySafe · Z-Pass Audit · Z-Code Shield · Z-File Guard · Z-Link Shield · Z-Privacy Check · Z-Scan · Z-Net. " +
            "بقية المحركات قيد التطوير ولا تُعرض كجاهزة قبل اكتمالها.", color = Zcl.Amber, fontSize = 12.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onBack) { Text("رجوع") }
    }
}

@Composable
fun SettingsScreen(reduced: Boolean, onReduced: (Boolean) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val log = remember { LocalLog(ctx) }
    var confirmClear by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("الإعدادات", color = Zcl.Cyan, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("وضع تقليل الحركة", color = Zcl.Ice)
                Text("يوقف حركة الخلفية لواجهة أهدأ وبطارية أقل", color = Zcl.Graphite, fontSize = 11.sp)
            }
            Switch(reduced, onReduced)
        }
        Text("الخصوصية: البيانات والسجل محلية. التطبيق لا يرسل ملفاتك أو مفاتيحك أو سجلاتك لأي خادم. الاتصال بالإنترنت يحدث فقط عند تشغيلك Z-Scan أو قياس الشبكة.",
            color = Zcl.Ice, fontSize = 13.sp)
        Button({ confirmClear = true }) { Text("مسح السجل المحلي") }
        Spacer(Modifier.weight(1f))
        OutlinedButton(onBack) { Text("رجوع") }
    }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        confirmButton = { TextButton({ log.clear(); confirmClear = false }) { Text("مسح") } },
        dismissButton = { TextButton({ confirmClear = false }) { Text("إلغاء") } },
        title = { Text("مسح السجل؟") },
        text = { Text("سيُحذف سجل العدادات المحلي فقط، ولن تُحذف أي ملفات.") }
    )
}
