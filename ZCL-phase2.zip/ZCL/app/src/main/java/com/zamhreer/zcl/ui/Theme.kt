package com.zamhreer.zcl.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Zcl {
    val Void = Color(0xFF02070F)
    val Navy = Color(0xFF071526)
    val Cyan = Color(0xFF35C8FF)
    val Ice = Color(0xFFEAF6FF)
    val Graphite = Color(0xFF8DA2B5)
    val Red = Color(0xFFFF4D5E)
    val Amber = Color(0xFFFFA64D)
    val Green = Color(0xFF3DDC97)
}

@Composable
fun ZclTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Zcl.Void, surface = Zcl.Navy,
            primary = Zcl.Cyan, onPrimary = Zcl.Void,
            onBackground = Zcl.Ice, onSurface = Zcl.Ice
        ),
        content = content
    )
}
