package com.zamhreer.zcl.analysis

enum class Severity(val ar: String, val weight: Int) {
    CRITICAL("حرجة", 60), HIGH("عالية", 35), MEDIUM("متوسطة", 15), LOW("منخفضة", 5), INFO("معلومة", 0)
}

data class Finding(
    val id: String,
    val title: String,
    val severity: Severity,
    val confidence: String,
    val evidence: String,
    val explanation: String,
    val recommendation: String,
    val line: Int = 0
)

object ZclReport {
    const val APP_VERSION = "2.0.0-phase4"
    data class Section(val target: String, val verdict: String, val findings: List<Finding>)

    fun text(engine: String, rulesVersion: String, status: String, sections: List<Section>, limits: List<String>): String {
        val sb = StringBuilder()
        val date = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        sb.appendLine("ZAMHREER CYBER LAB — تقرير فحص")
        sb.appendLine("التطبيق: ZCL $APP_VERSION")
        sb.appendLine("معرف التقرير: ${java.util.UUID.randomUUID().toString().take(8)}")
        sb.appendLine("التاريخ: $date")
        sb.appendLine("المحرك: $engine")
        sb.appendLine("إصدار القواعد: $rulesVersion")
        sb.appendLine("حالة العملية: $status")
        sb.appendLine("=".repeat(40))
        sections.forEach { s ->
            sb.appendLine("الهدف: ${s.target}")
            sb.appendLine("الحكم: ${s.verdict}")
            if (s.findings.isEmpty()) sb.appendLine("  (لا توجد مؤشرات)")
            s.findings.forEachIndexed { i, f ->
                sb.appendLine("  ${i + 1}. [${f.severity.ar}] ${f.title} (${f.id}) — ثقة: ${f.confidence}")
                if (f.line > 0) sb.appendLine("     السطر: ${f.line}")
                if (f.evidence.isNotEmpty()) sb.appendLine("     الدليل: ${f.evidence}")
                sb.appendLine("     التفسير: ${f.explanation}")
                sb.appendLine("     التوصية: ${f.recommendation}")
            }
            sb.appendLine("-".repeat(40))
        }
        sb.appendLine("حدود الفحص:")
        limits.forEach { sb.appendLine("  - $it") }
        sb.appendLine("=".repeat(40))
        sb.appendLine("ZAMHREER CYBER LAB")
        sb.appendLine("تطوير وبرمجة: حسن نصرت حربي")
        sb.appendLine("© جميع الحقوق محفوظة للمبرمج حسن نصرت حربي")
        sb.appendLine("https://t.me/rtf60")
        return sb.toString()
    }
}
