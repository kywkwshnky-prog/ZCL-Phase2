package com.zamhreer.zcl

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import com.zamhreer.zcl.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                ZclTheme {
                    var screen by rememberSaveable { mutableStateOf("splash") }
                    androidx.activity.compose.BackHandler(enabled = screen != "home" && screen != "splash") { screen = "home" }
                    Box(Modifier.fillMaxSize()) {
                        when (screen) {
                            "splash" -> SplashScreen { screen = "home" }
                            "home" -> DashboardScreen(onOpen = { screen = it }, onAbout = { screen = "about" }, onSettings = { screen = "settings" })
                            "about" -> AboutScreen { screen = "home" }
                            "settings" -> SettingsScreen { screen = "home" }
                            "hash" -> HashScreen { screen = "home" }
                            "crypto" -> CryptoScreen { screen = "home" }
                            "keys" -> KeySafeScreen { screen = "home" }
                            "pass" -> PassScreen { screen = "home" }
                        }
                    }
                }
            }
        }
    }
}
