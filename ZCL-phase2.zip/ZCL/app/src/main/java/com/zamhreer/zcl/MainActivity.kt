package com.zamhreer.zcl

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.zamhreer.zcl.data.Prefs
import com.zamhreer.zcl.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(this)
        setContent {
            var reduced by remember { mutableStateOf(prefs.reducedMotion) }
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl, LocalReducedMotion provides reduced) {
                ZclTheme {
                    var screen by rememberSaveable { mutableStateOf("splash") }
                    BackHandler(enabled = screen != "home" && screen != "splash") { screen = "home" }
                    Box(Modifier.fillMaxSize()) {
                        ZclBackground()
                        val home = { screen = "home" }
                        when (screen) {
                            "splash" -> SplashScreen { screen = "home" }
                            "home" -> DashboardScreen(onOpen = { screen = it }, onAbout = { screen = "about" }, onSettings = { screen = "settings" })
                            "about" -> AboutScreen(home)
                            "settings" -> SettingsScreen(reduced, { reduced = it; prefs.reducedMotion = it }, home)
                            "hash" -> HashScreen(home)
                            "crypto" -> CryptoScreen(home)
                            "keys" -> KeySafeScreen(home)
                            "pass" -> PassScreen(home)
                            "code" -> CodeScreen(home)
                            "link" -> LinkScreen(home)
                            "file" -> FileGuardScreen(home)
                            "privacy" -> PrivacyScreen(home)
                            "scan" -> ScanScreen(home)
                            "net" -> NetScreen(home)
                        }
                    }
                }
            }
        }
    }
}
