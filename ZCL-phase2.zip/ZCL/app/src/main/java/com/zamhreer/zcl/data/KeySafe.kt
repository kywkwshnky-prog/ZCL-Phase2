package com.zamhreer.zcl.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.zamhreer.zcl.crypto.ZclCrypto
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Keys are random 256-bit values wrapped by a non-exportable Android Keystore AES-GCM key.
 * Wrapped blobs live in app-private storage. A key is therefore only usable on this device
 * unless the user explicitly exports it (password-encrypted).
 */
class KeySafe(context: Context) {
    private val dir = File(context.filesDir, "keys").apply { mkdirs() }
    private val alias = "zcl_wrap_v1"

    private fun wrapKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256).build())
        return gen.generateKey()
    }

    fun validName(n: String) = Regex("[A-Za-z0-9_-]{1,32}").matches(n)
    private fun file(n: String) = File(dir, "$n.key")

    fun list(): List<String> = dir.listFiles { f -> f.name.endsWith(".key") }
        ?.map { it.name.removeSuffix(".key") }?.sorted() ?: emptyList()

    fun create(name: String): Boolean {
        if (!validName(name) || file(name).exists()) return false
        val key = ZclCrypto.randomKey()
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, wrapKey())
        file(name).writeBytes(c.iv + c.doFinal(key))
        key.fill(0)
        return true
    }

    fun get(name: String): ByteArray? {
        val f = file(name)
        if (!validName(name) || !f.exists()) return null
        val blob = f.readBytes()
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, wrapKey(), GCMParameterSpec(128, blob.copyOfRange(0, 12)))
        return c.doFinal(blob.copyOfRange(12, blob.size))
    }

    fun delete(name: String) { if (validName(name)) file(name).delete() }
}
