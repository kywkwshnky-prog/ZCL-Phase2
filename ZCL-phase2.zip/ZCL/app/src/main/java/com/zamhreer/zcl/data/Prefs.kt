package com.zamhreer.zcl.data

import android.content.Context

class Prefs(context: Context) {
    private val p = context.getSharedPreferences("zcl_prefs", Context.MODE_PRIVATE)
    var reducedMotion: Boolean
        get() = p.getBoolean("reduced_motion", false)
        set(v) { p.edit().putBoolean("reduced_motion", v).apply() }
}
