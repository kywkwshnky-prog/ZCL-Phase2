package com.zamhreer.zcl.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

/** Honest status model: an engine is only READY once its real implementation ships. */
enum class EngineStatus(val label: String) {
    READY("Ready"), PLANNED("قيد التطوير"), DISABLED("Disabled")
}

data class Engine(val id: String, val code: String, val title: String, val icon: ImageVector,
                  val phase: Int, val status: EngineStatus = EngineStatus.PLANNED)

val ENGINES = listOf(
    Engine("hash", "Z-Hash", "بصمات الملفات", Icons.Filled.Fingerprint, 2, EngineStatus.READY),
    Engine("code", "Z-Code Shield", "فحص الأكواد", Icons.Filled.Code, 3),
    Engine("crypto", "Z-Encrypt", "تشفير الملفات", Icons.Filled.Lock, 2, EngineStatus.READY),
    Engine("net", "Z-Net", "تحليل الشبكات", Icons.Filled.Hub, 5),
    Engine("scan", "Z-Scan", "فحص المواقع", Icons.Filled.Language, 4),
    Engine("keys", "Z-KeySafe", "إدارة المفاتيح", Icons.Filled.VpnKey, 2, EngineStatus.READY),
    Engine("report", "Z-Report", "التقارير", Icons.Filled.Description, 5),
    Engine("pass", "Z-Pass Audit", "قوة كلمات المرور", Icons.Filled.Password, 3, EngineStatus.READY),
    Engine("academy", "Z-Academy", "المختبر التعليمي", Icons.Filled.School, 6),
)
